import './enzyme.config.js';
import React from 'react';
import {shallow, mount} from 'enzyme';
import CustumUnits from '../src/components/Application/Settings/CustumUnits';

const startProperties = {
    'options': {
        'units': {'miles': 3959, 'kilometers': 6371},
        'activeUnit': 'miles',
        'serverPort': 'black-bottle.cs.colostate.edu:31401'
    }
};

function testUploadUnit() {
    const units = mount((
        <CustumUnits options={startProperties.options}/>
    ));

    let numberOfInputs = units.find('Input').length;
    expect(numberOfInputs).toEqual(2);

    let actualInputs = [];
    units.find('Input').map((input) => actualInputs.push(input.prop('name')));

    let expectedInputs = [
        'Name',
        'Radius'
    ];

    expect(actualInputs).toEqual(expectedInputs);
}
test('Testing for input fields', testUploadUnit);

function testButtonFields() {
    const units = mount((
        <CustumUnits options={startProperties.options}/>
    ));

    let numberOfInputs = units.find('Button').length;
    expect(numberOfInputs).toEqual(1);

    let actualInputs = [];
    units.find('Button').map((input) => actualInputs.push(input.prop('name')));

    let expectedInputs = [
        'createUnit'
    ];

    expect(actualInputs).toEqual(expectedInputs);
}

test('Testing for create new unit', testButtonFields);

function testTableExists() {
    const units = mount((
        <CustumUnits options={startProperties.options}/>
    ));

    let numberOfInputs = units.find('Table').length;
    expect(numberOfInputs).toEqual(1);

    let actualInputs = [];
    units.find('Table').map((input) => actualInputs.push(input.prop('name')));

    let expectedInputs = [
        'avaUnits'
    ];

    expect(actualInputs).toEqual(expectedInputs);
}

test('Testing for create new unit', testTableExists);
