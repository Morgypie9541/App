import './enzyme.config.js';
import React from 'react';
import {shallow, mount} from 'enzyme';
import FindItinerary from '../src/components/Application/Itinerary/FindItinerary';

const startProperties = {
    "places" : [],
    "match" : "fort",
    "limit": 50,
    "found" : null,
    "popoverOpen": false,
    "cSelected": [],
    "errorMessage": null,
    'options': {
        'units': {'miles': 3959, 'kilometers': 6371},
        'activeUnit': 'miles',
        'serverPort': 'black-bottle.cs.colostate.edu:31401',
        'places':[]
    }
};

function testSearchExists() {
    const preview = mount((
        <FindItinerary options={startProperties.options}/>
    ));

    let numberOfInputs = preview.find('Input').length;
    expect(numberOfInputs).toEqual(3);

    let actualInputs = [];
    preview.find('Input').map((input) => actualInputs.push(input.prop('name')));

    let expectedInputs = [
        'searchField',
        undefined,
        undefined
    ];

    expect(actualInputs).toEqual(expectedInputs);
}

test('Testing existence of Form in FindItinerary', testSearchExists);

function testButtonFields() {
    const itinerary = mount((
        <FindItinerary options={startProperties.options}/>
    ));

    let numberOfInputs = itinerary.find('Button').length;
    expect(numberOfInputs).toEqual(1);

    let actualInputs = [];
    itinerary.find('Button').map((input) => actualInputs.push(input.prop('name')));

    let expectedInputs = [
        undefined
    ];

    expect(actualInputs).toEqual(expectedInputs);
}

test('Testing filter fields exist in FindItinerary', testButtonFields);
