import './enzyme.config.js';
import React from 'react';
import {shallow, mount} from 'enzyme';
import Itinerary from '../src/components/Application/Itinerary/Itinerary';
import { createErrorBanner } from '../src/components/Application/Application';
// import testFile from './testFiles/test.json';
const startProperties = {
    'options': {
        'units': {'miles': 3959, 'kilometers': 6371},
        'activeUnit': 'miles',
        'serverPort': 'black-bottle.cs.colostate.edu:31401'
    }
};

function testUploadField() {
    const itinerary = mount((
        <Itinerary options={startProperties.options}/>
    ));

    let numberOfInputs = itinerary.find('Input').length;
    expect(numberOfInputs).toEqual(7);

    let actualInputs = [];
    itinerary.find('Input').map((input) => actualInputs.push(input.prop('name')));

    let expectedInputs = [
        'itineraryFile',
        'searchField',
        undefined,
        undefined,
        undefined,
        undefined,
        undefined
    ];

    expect(actualInputs).toEqual(expectedInputs);
}

test('Testing createItineraryUpload() function in Itinerary', testUploadField);

function testButtonFields() {
    const itinerary = mount((
        <Itinerary options={startProperties.options}/>
    ));

    let numberOfInputs = itinerary.find('Button').length;
    expect(numberOfInputs).toEqual(9);

    let actualInputs = [];
    itinerary.find('Button').map((input) => actualInputs.push(input.prop('name')));

    let expectedInputs = [

        undefined,
        'uploadFile',
        'None',
        'Short',
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,

    ];

    expect(actualInputs).toEqual(expectedInputs);
}

test('Testing createItineraryUpload() and saveItinerary() function in Itinerary', testButtonFields);

function testMapExist() {
    const itinerary = mount((
        <Itinerary options={startProperties.options}/>
    ));

    let numberOfInputs = itinerary.find('Map').length;
    expect(numberOfInputs).toEqual(1);

    let actualInputs = [];
    itinerary.find('Map').map((input) => actualInputs.push(input.prop('name')));

    let expectedInputs = [
        'itineraryMap'
    ];

    expect(actualInputs).toEqual(expectedInputs);
}

test('Testing if Map exists in the Itinerary', testMapExist);

function testConvertOneCoordinate() {
    const itinerary = mount((
        <Itinerary options={startProperties.options}/>
    ));

    let place =
        {
            "id": "1",
            "name": "Adams County",
            "latitude": "39.87°N",
            "longitude": "104.33°W"
        };
    var converted = itinerary.instance().convertOneCoordinate(place);
    expect(converted).toEqual({"id":"1","name":"Adams County","latitude":"39.87","longitude":"-104.33"});
}
test('Testing convertOneCoordinate', testConvertOneCoordinate);

function testMapBounds(){
    const itinerary = mount((
        <Itinerary options={startProperties.options}/>
    ));
    let expectedBounds = L.latLngBounds(L.latLng(80, -170), L.latLng(-80, 170))

    let bounds = itinerary.instance().mapBounds();
    expect(bounds).toEqual(expectedBounds)
}

test('Testing mapBounds', testMapBounds);

function testBounderies(){
    const itinerary = mount((
        <Itinerary options={startProperties.options}/>
    ));
    let expectedBounds = L.latLngBounds(L.latLng(41, -109), L.latLng(37, -102))
    let expectedOval = L.latLng(40.576179, -105.080773);

    let bounds = itinerary.instance().coloradoGeographicBoundaries();
    let bound2 = itinerary.instance().csuOvalGeographicCoordinates();
    expect(bounds).toEqual(expectedBounds)
    expect(bound2).toEqual(expectedOval)

}

test('test coordinates', testBounderies);

// function testInputOnChange() {
//     const itinerary = mount((
//         <Itinerary options={startProperties.options}/>
//     ));
//
//     simulateOnChangeEvent(itinerary);
//
//     expect(itinerary.state().validFile).toEqual(true);
//     expect(itinerary.state().options).toEqual({ "title":"My Trip",
//                                                 "earthRadius":"3958.761316" });
//     expect(itinerary.state().places).toEqual([{"id":"dnvr", "name":"Denver",       "latitude": "39.7392",   "longitude": "-104.9903"},
//                                             {"id":"bldr", "name":"Boulder",      "latitude": "40.01499",  "longitude": "-105.27055"},
//                                             {"id":"foco", "name":"Fort Collins", "latitude": "40.585258", "longitude": "-105.084419"}]);
// }
//
// function simulateOnChangeEvent(reactWrapper) {
//     testFile.type='json';
//     let event = {target: {files:[testFile]}};
//     reactWrapper.find('#fileHandler').at(0).simulate('change', event);
//     reactWrapper.update();
// }
//
// test('Testing the onChange event of file handler', testInputOnChange);