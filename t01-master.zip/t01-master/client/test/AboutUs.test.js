import './enzyme.config.js';
import React from 'react';
import {shallow, mount} from 'enzyme';
import AboutUs from '../src/components/Application/AboutUs/AboutUs';


function testForSections() {
    const about = mount((
        <AboutUs/>
    ));

    let numberOfInputs = about.find('Pane').length;
    expect(numberOfInputs).toEqual(6);

    let actualInputs = [];
    about.find('Pane').map((input) => actualInputs.push(input.prop('name')));

    let expectedInputs = [
        'intro',
        'kalebs',
        'alyssas',
        'miriams',
        'wills',
        'morgans'

    ];

    expect(actualInputs).toEqual(expectedInputs);
}
test('Testing for all fields in AboutUs', testForSections);

function testImages() {
    const about = mount((
        <AboutUs/>
    ));

    let numberOfInputs = about.find('img').length;
    expect(numberOfInputs).toEqual(5);

    let actualInputs = [];
    about.find('img').map((input) => actualInputs.push(input.prop('name')));

    let expectedInputs = [
        'kaleb',
        'alyssa',
        'miriam',
        'will',
        'morgan'

    ];

    expect(actualInputs).toEqual(expectedInputs);
}

test('Testing for Images', testImages);
