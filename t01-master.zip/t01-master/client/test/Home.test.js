import './enzyme.config.js';
import React from 'react';
import {shallow, mount} from 'enzyme';
import Home from '../src/components/Application/Home';

function testMapExist() {
    const home= mount((
        <Home/>
    ));

    let numberOfInputs = home.find('Map').length;
    expect(numberOfInputs).toEqual(1);

    let actualInputs = [];
    home.find('Map').map((input) => actualInputs.push(input.prop('name')));

    let expectedInputs = [
        'homeMap'
    ];

    expect(actualInputs).toEqual(expectedInputs);
}

test('Testing if Map exists in the Home', testMapExist);