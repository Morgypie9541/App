import './enzyme.config.js';
import React from 'react';
import {shallow, mount} from 'enzyme';
import ItineraryPreview from '../src/components/Application/Itinerary/ItineraryPreview';

const startProperties = {
    'options': {
        'units': {'miles': 3959, 'kilometers': 6371},
        'activeUnit': 'miles',
        'serverPort': 'black-bottle.cs.colostate.edu:31401',
        'places':[]
    }
};


function testTableExists() {
    const preview = mount((
        <ItineraryPreview options={startProperties.options}/>
    ));

    let numberOfInputs = preview.find('Table').length;
    expect(numberOfInputs).toEqual(1);

    let actualInputs = [];
    preview.find('Table').map((input) => actualInputs.push(input.prop('name')));

    let expectedInputs = [
        'preview'
    ];

    expect(actualInputs).toEqual(expectedInputs);
}
test('Testing existence of Table in itinerary preview', testTableExists);
function testToFrom() {
    const preview = mount((
        <ItineraryPreview options={startProperties.options}/>
    ));
    //test no places
    let placesNone = []
    //test one place
    let places1 = [{"id": "kpashak", "name": "Black Bottle Brewery", "municipality": "Fort Collins", "latitude": "40.57","longitude": "-105.08", "altitude": "5003"}]


    let actualplacesNone = preview.instance().toFromDists(placesNone)
    let distances = [0]
    let ret = [{"destination": "-", "distance": "-", "origin": "Black Bottle Brewery", "totalDistance": "-"}]
    let actualplaces1 = preview.instance().toFromDists(places1,distances)


    expect(ret).toEqual(actualplaces1)
    expect(actualplacesNone).toEqual(actualplacesNone)

}

test('test toFromDist with one and no places', testToFrom);

function testMoveUp() {
    const app = mount((
        <ItineraryPreview options={startProperties.options}/>
    ));
    app.mount((
        <ItineraryPreview options={startProperties.options}/>
    ));

    let index = 0;

    expect(app.instance().moveUp(index)).toEqual(false);
}

test('Testing move up', testMoveUp);
