/*
    Code in this file is from url: https://www.codexpedia.com/javascript/javascript-create-read-and-delete-cookies/

    The functions in this file are meant to help set, read, and delete cookies for long-term storage.
    Also manages default settings for items like units that might not have default cookies saved.
 */

export function setCookie(name, value, daysTilExpired){
    deleteCookie(name);

    var currentDate = new Date();
    currentDate.setTime(currentDate.getTime() + (daysTilExpired * 1000 * 60 * 60 * 24));
    var expiresDate = "expires=" + currentDate.toGMTString();
    window.document.cookie = name + "=" + value + "; " + expiresDate;
}

// returns a string, so if you're looking for yours as a json, you need to use JSON.parse on the result
function readCookie(name){
    var actualName = name + "=";
    var cookiesArr = window.document.cookie.split(';');

    for(var i = 0; i < cookiesArr.length; i++){
        var cookie = cookiesArr[i].trim();
        if(cookie.indexOf(actualName) == 0){
            return cookie.substring(actualName.length, cookie.length);
        }
    }

    return "";
}

function deleteCookie(name){
    var currentDate = new Date();
    currentDate.setTime(currentDate.getTime() - (1000 * 60 * 60 * 24));
    var expiresDate = "expires=" + currentDate.toGMTString();
    window.document.cookie = name + "=" + "; " + expiresDate;
}

export function getSavedUnits(){
    var defaultUnits = {'kilometers': 6378, 'miles':3959, 'nautical miles': 3440};
    var savedInCookies = readCookie('units');

    if(savedInCookies == ""){
        setCookie('units', JSON.stringify(defaultUnits), 100);
        return defaultUnits;
    }
    else return JSON.parse(savedInCookies);
}