import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import { Button } from 'reactstrap'
import { Form, Label, Input } from 'reactstrap'
import { sendServerRequestWithBody } from '../../../api/restfulAPI'
import Coordinates from 'coordinate-parser';
import Pane from '../Pane';
import JSONSchemas from "../Misc/JSONSchemas";

export default class Calculator extends Component {
    constructor(props) {
        super(props);

        this.updateLocationOnChange = this.updateLocationOnChange.bind(this);
        this.calculateDistance = this.calculateDistance.bind(this);
        this.createInputField = this.createInputField.bind(this);
        this.state = {
            errorMessage: null
        };
    }

    render() {
        return (
            <Container>
                { this.state.errorMessage }
                <Row>
                    <Col>
                        {this.createHeader()}
                    </Col>
                </Row>
                <Row>
                        {this.createForm('origin')}
                        {this.createForm('destination')}
                        {this.createDistance()}
                </Row>
            </Container>
        );
    }

    createHeader() {
        return (
            <Pane header={'Calculator'}
                  bodyJSX={<div>Determine the distance between the origin and destination.
                      Change the units on the <b>Options</b> page.</div>}/>
        );
    }

    createInputField(stateVar, coordinate) {
        let updateStateVarOnChange = (event) => {
            this.updateLocationOnChange(stateVar, event.target.name, event.target.value)};

        let capitalizedCoordinate = coordinate.charAt(0).toUpperCase() + coordinate.slice(1);
        return (
            <Input name={coordinate} placeholder={capitalizedCoordinate}
                   id={`${stateVar}${capitalizedCoordinate}`}
                   value={this.props.calculator[stateVar][coordinate]}
                   onChange={updateStateVarOnChange}
                   style={{width: "100%"}} />
        );

    }

    createForm(stateVar) {
        return (
            <Col xs={12} sm={6} md={4} lg={3}>
                <Pane header={stateVar.charAt(0).toUpperCase() + stateVar.slice(1)}
                      bodyJSX={
                          <Form >
                              {this.createInputField(stateVar, 'latitude')}
                              {this.createInputField(stateVar, 'longitude')}
                          </Form>
                      }
                />
            </Col> );
    }

    createDistance() {
        if(this.props.calculator.distance==0 && this.props.calculator.origin.latitude!=='' && this.props.calculator.origin.longitude!=='' && this.props.calculator.destination.latitude!=='' && this.props.calculator.destination.longitude!==''){

            this.calculateDistance();
        }
        return(
                <Col xs={12} sm={6} md={4} lg={3}>
                <Pane header={'Distance'}
                      bodyJSX={
                          <div>
                              <h5 id='distance'>{this.props.calculator.distance} {this.props.options.activeUnit}</h5>
                              <p id='inputError'> </p>
                          </div>}
                />
            </Col>
        );
    }

    calculateDistance() {
        if(this.checkAlpha(this.props.calculator.origin.latitude, this.props.calculator.destination.latitude, this.props.calculator.origin.longitude, this.props.calculator.destination.longitude))
            return;

        var latLonDegrees = this.convertCoordinatesToDegrees(this.props.calculator.origin, this.props.calculator.destination);
        let orglat = latLonDegrees.origin.latitude.toString();
        let orglon = latLonDegrees.origin.longitude.toString();
        let deslat = latLonDegrees.destination.latitude.toString();
        let deslon = latLonDegrees.destination.longitude.toString();

        const tipDistRequest = {
            'requestType'        : 'distance',
            'requestVersion'     : 5,
            'origin'      : {latitude: orglat,longitude: orglon},
            'destination' : {latitude: deslat, longitude: deslon},
            'earthRadius' : this.props.options.units[this.props.options.activeUnit]
        };

        //document.getElementById('inputError').innerHTML = "";

        if(this.checkLatLonBounds(latLonDegrees.origin.latitude, latLonDegrees.destination.latitude, 90, -90)) return;
        if(this.checkLatLonBounds(latLonDegrees.origin.longitude, latLonDegrees.destination.longitude, 180, -180)) return;

        this.sendToServer(tipDistRequest);
    }

    sendToServer(tipDistRequest){
        sendServerRequestWithBody('distance', tipDistRequest, this.props.settings.serverPort)
            .then((response) => {
                if(response.statusCode >= 200 && response.statusCode <= 299) {
                    if(JSONSchemas.ValidateDistanceSchema(response.body)) {
                        this.setState({
                            // distance: response.body.distance,
                            errorMessage: null
                        });
                        let distance = Object.assign({}, this.props.calculator);
                        distance.distance = response.body.distance;
                        this.props.updateCalculator(distance);
                    }
                    else{
                        this.setState({
                            errorMessage: this.props.createErrorBanner(
                                "Error",
                                400,
                                `Response from ${this.props.settings.serverPort} failed. The server has failed, please' +
                                    'Call Will McDonald at 208-684-2233 for technical support. You Should have listened....' +
                                    'This will be very painful...for you...`
                            )
                        });
                    }
                }
                else {
                        this.setState({
                            errorMessage: this.props.createErrorBanner(
                                response.statusText,
                                response.statusCode,
                                `Request to ${ this.props.settings.serverPort } failed.`
                            )
                        });
                }
            });
    }

    convertCoordinatesToDegrees(origin, dest){
        var latLonDegrees = {
            origin: {latitude: '', longitude: ''},
            destination: {latitude: '', longitude: ''}
        };

        var o = new Coordinates(origin.latitude + ' ' + origin.longitude);
        var d = new Coordinates(dest.latitude + ' ' + dest.longitude);

        latLonDegrees.origin.latitude = o.getLatitude();
        latLonDegrees.origin.longitude = o.getLongitude();

        latLonDegrees.destination.latitude = d.getLatitude();
        latLonDegrees.destination.longitude = d.getLongitude();

        return latLonDegrees;
    }

    checkAlpha(lat1, lat2, lon1, lon2){
        var exp = /^[a-zA-Z]+$/;
        if(lat1.toString().match(exp) || lat2.toString().match(exp) || lon1.toString().match(exp) || lon2.toString().match(exp)){
            document.getElementById('inputError').innerHTML = "Incorrect format for Lat/Lon.";
            return true;
        }
        else document.getElementById('inputError').innerHTML = ' ';
    }

    checkLatLonBounds(lat1, lat2, upperBound, lowerBound){
        if (parseFloat(lat1) < lowerBound || parseFloat(lat2) < lowerBound || parseFloat(lat1) > upperBound || parseFloat(lat2) > upperBound) {
            document.getElementById('inputError').innerHTML = "Incorrect bounds for latitude or longitude. Must be between -90 and 90 for latitude and between -180 and 180 for longitude.";
            return true;
        }
        else document.getElementById('inputError').innerHTML = ' ';
    }

    updateLocationOnChange(stateVar, field, value) {
        let location = Object.assign({}, this.props.calculator);
        location[stateVar][field] = value;
        location['distance']=0;
        this.props.updateCalculator(location);
    }
}