import React, {Component} from 'react';
import {Container, Row, Col} from 'reactstrap';
import Pane from '../Pane';
import AlyssaPicture from './Images/AlyssaPicture.jpg';
import KalebW from './Images/KalebW.jpg';
import MiriamPicture from './Images/MiriamPicture.jpg';
import willdog from './Images/willdog.jpg';
import MorganRoe from './Images/MorganRoe.jpg';

export default class About extends Component{
   constructor(props){
    super(props);
   }

    render(){
     return(
         <Container>
             <Row>
                 <Col xs="12">
                     {this.heading()}
                 </Col>
             </Row>
             <Row>
                     {this.newInfo('kaleb','Kaleb Welsh', KalebW,'   I am a Senior at Colorado State University, working towards a Computer Science Major and a Mathematics Minor.\n' +
                         '                              I\'m originally from the Denver Metro Area and love to go on a peaceful hikes.\n' +
                         '                          ')}
                     {this.newInfo('alyssa','Alyssa Watts', AlyssaPicture,'I am a junior at Colorado State University, with a Computer Science Major and a Mathematics Minor. I have two amazing dogs, Molly and Lucky, who are a lab mix and border collie.' )}
                     {this.newInfo('miriam','Miriam Alzamily',MiriamPicture,'I am currently a junior at Colorado State University, where I am majoring in computer science. I am from Aurora, CO. In my spare time I like to watch movies and listen to music.')}
                     {this.newInfo('will','Will McDonald',willdog,'I am a Junior computer science student at CSU. Outside of school, I like playing music and Ultimate Frisbee.')}
                     {this.newInfo('morgan','Morgan Roe',MorganRoe,'(On left) Computer Science student at CSU graduating Spring 2019. Former Marine, avid reader, and computer enthusiast. Happy father to a baby boy. I also have many stuffed animals.')}
             </Row>
         </Container>
     );
   }

    heading() {
    return (
        <Pane name='intro' header={'About Us'}
              bodyJSX={'Welcome to our Team Doggos About Us Page!' +
              ' Here you can find out more about each team member!'}/>
    );
    }

    newInfo(name, header, src,bio) {
        return(
            <Col xs={12} sm={6} md={4} lg={3}>
                <Pane name={name+'s'} header={header}
                      bodyJSX={
                          <div>
                              <img name={name} src={src} height={250} width={250}/>
                              <div>
                                  {bio}
                               </div>
                          </div>
                      }/>
            </Col>
        );
    }

}