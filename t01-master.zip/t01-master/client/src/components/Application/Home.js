import React, {Component} from 'react';
import {Container, Row, Col} from 'reactstrap';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import 'leaflet/dist/leaflet.css';
import { Map, Marker, Popup, TileLayer} from 'react-leaflet';
import Pane from './Pane'

/*
 * Renders the home page.
 */
export default class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            markers: [this.csuOvalGeographicCoordinates()]
        };
        this.getLocation = this.getLocation.bind(this)

    }


    render() {
    return (
      <Container>
        <Row>
            {this.renderIntro()}
            {this.renderMap()}

        </Row>
      </Container>
    );
  }

  renderMap() {
    return (
      <Col xs={12} sm={12} md={12} lg={12} xl={12}>
          <Pane header={'Where Am I?'}
                bodyJSX={this.renderLeafletMap()}/>
      </Col>
    );
  }

  renderLeafletMap() {
    // initial map placement can use either of these approaches:
    // 1: bounds={this.coloradoGeographicBoundaries()}
    // 2: center={this.csuOvalGeographicCoordinates()} zoom={10}
    return (
      <Map name='homeMap' center={this.csuOvalGeographicCoordinates()} zoom={10}
           style={{height: 500, maxwidth: 700}} onLoad = {this.getLocation()}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                   attribution="&copy; <a href=&quot;http://osm.org/copyright&quot;>OpenStreetMap</a> contributors"
        />
          {this.state.markers.map((pos, idx) =>
              <Marker key={`marker-${idx}`} position={pos} icon={this.markerIcon()}>
                <Popup>
                  <span>Your Location </span>
                </Popup>
              </Marker>
          )}
      </Map>
    )
  }

  renderIntro() {
    return(
      <Col xs={12} sm={12} md={12} lg={12} xl={12}>
          <Pane header={'Welcome!'}
                bodyJSX={'Let us help you plan your next trip. Use the Itinerary page to get started!'}/>
      </Col>
    );
  }

  coloradoGeographicBoundaries() {
    // northwest and southeast corners of the state of Colorado
    return L.latLngBounds(L.latLng(41, -109), L.latLng(37, -102));
  }

  csuOvalGeographicCoordinates() {
    return L.latLng(40.576179, -105.080773);
  }

  markerIcon() {
    // react-leaflet does not currently handle default marker icons correctly,
    // so we must create our own
    return L.icon({
      iconUrl: icon,
      shadowUrl: iconShadow,
      iconAnchor: [12,40]  // for proper placement
    })
  }
  getLocation(){
        //supported
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function getCoords(position) {
                var lat = position.coords.latitude;
                var lng = position.coords.longitude;
                //add to current markers list
                const markers = this.state.markers;
                markers.pop();
                markers.push([lat,lng])
                this.setState(markers)

            }.bind(this))

        }
  }
}
