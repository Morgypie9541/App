import React, { Component } from 'react'
import { Card, CardHeader, CardBody, Form, Input } from 'reactstrap'
import { Row, Col, Button, Table, Alert } from 'reactstrap'
import {setCookie} from '../Cookies';


export default class CustomUnits extends Component {
    constructor(props) {
        super(props)
        this.state={
            inputName: '',
            inputRadius: '',
            popoverOpen: false
        };
        this.toggle=this.toggle.bind(this);
        this.updateUnits=this.updateUnits.bind(this);
        this.updateInputName=this.updateInputName.bind(this);
        this.updateInputRadius=this.updateInputRadius.bind(this);
    }


    render(){
        return(
            <Card className='text-center'>
                <CardHeader className='bg-csu-gold text-white font-weight-semibold'>Custom Units</CardHeader>
                <CardBody>
                    <Table name='avaUnits' hover>
                        <thead>
                        <tr>
                            <th>Unit</th>
                            <th>Radius</th>
                        </tr>
                        </thead>
                        <tbody style={{height:150,overflow:'scroll'}}>
                        {this.renderUnits(Object.keys(this.props.options.units),Object.values(this.props.options.units))}
                        </tbody>
                    </Table>
                    <div>
                        {this.submitUnit()}
                        <Button name='createUnit' onClick={this.updateUnits} id='createUnit' className='btn-csu w-100'>Create</Button>
                        <Alert color="danger" isOpen={this.state.popoverOpen} toggle={this.toggle}>
                            Radius must be numeric (0-9).
                        </Alert>
                    </div>
                </CardBody>
            </Card>
        );
    }

    renderUnits(names, values){
        return names.map((unit, value) =>
            <tr key={value}>
                <td scope='row'>
                    {unit.charAt(0).toUpperCase() + unit.slice(1)}
                </td>
                <td>
                    {values[value]}
                </td>
            </tr>
        );
    }

    submitUnit(){
        return(
            <Form >
                <Row>
                    {this.newInputField(this.updateInputName, this.state.inputName, 'Name')}
                    {this.newInputField(this.updateInputRadius, this.state.inputRadius, 'Radius')}
                </Row>
                <br/>
            </Form >
        );
    }

    newInputField(func, val, placeHolder){
        return(
            <Col xs="12" sm="12" md="6" lg="6" xl="6">
                <Input  name={placeHolder}
                        onChange={func}
                        value={val}
                        placeholder={placeHolder}
                />
            </Col>
        );
    }

    toggle(){
        this.setState({popoverOpen:false});
    }

    updateUnits(){
        if(this.state.inputName=='' || this.state.inputRadius==''){
            return;
        }
        else if(this.state.inputRadius.match(/[a-z]/i)) {
            this.setState({popoverOpen:true});
            return;
        }
        let newUnits= Object.assign({},this.props.options.units);
        newUnits[this.state.inputName.charAt(0).toUpperCase()+this.state.inputName.substr(1)]=parseFloat(this.state.inputRadius);
        Object.keys(newUnits).sort();
        this.setState({
            inputName: '',
            inputRadius: ''
        });
        this.props.updateOption('units',newUnits);
        setCookie('units', JSON.stringify(newUnits), 100);
    }

    updateInputName(event){
        this.setState({inputName: event.target.value});
    }
    updateInputRadius(event){
        this.setState({inputRadius: event.target.value});
    }
}