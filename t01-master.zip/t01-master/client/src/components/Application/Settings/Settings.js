import React, {Component} from 'react';
import {Container, Row, Col, Button} from 'reactstrap';
import Interop from './Interop';
import CustomUnits from './CustumUnits';
import Pane from '../Pane';
import {setCookie} from '../Cookies';

/**
 * The Settings component.
 * This component is responsible for managing global client settings, such as
 * the server and default options.
 */
export default class Settings extends Component {
  constructor(props) {
    super(props);
    this.resetUnits=this.resetUnits.bind(this);
  }

  render() {
    return (
      <Container>
        <Row>
          <Col xs="12">
            {this.heading()}
          </Col>
        </Row>
        <Row>
          <Col xs="12" sm="12" md="6" lg="4" xl="3">
            <Interop serverPort={this.props.settings.serverPort}
                     serverConfig={this.props.serverConfig}
                     updateSetting={this.props.updateSetting}/>
          </Col>
          <Col xs="12" sm="12" md="9" lg="6" xl="4">
              <CustomUnits  options={this.props.options}
                            updateOption={this.props.updateOption}
              />
          </Col>
        </Row>
      </Container>
    );
  }


  heading() {
    return (
        <Pane header={'Settings'}
              bodyJSX={
                  <Row>
                      <Col xs="12" sm="12" md="6" lg="6" xl="6">
                  Change global client settings, or add Units to use in the Calculator!
                      </Col>
                      <Col xs="12" sm="12" md="6" lg="6" xl="6">
                          <Button onClick={this.resetUnits}>Reset Units</Button>
                      </Col>
                  </Row>
              }/>
    );
  }

  resetUnits(){
      let oldUnits= Object.assign({},this.props.options.units);
      oldUnits={'kilometers': 6378, 'miles':3959, 'nautical miles': 3440};
      this.props.updateOption('units',oldUnits);
      setCookie('units', JSON.stringify(oldUnits), 100);
  }
}
