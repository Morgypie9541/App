import React, {Component} from 'react';
import {Container, Row, Col} from 'reactstrap';
import { Button } from 'reactstrap';
import { Form, Label, Input, FormText, FormGroup } from 'reactstrap';
import { Card, CardHeader, CardBody} from 'reactstrap'
import { Table } from 'reactstrap'
import 'leaflet/dist/leaflet.css';
import { Map, Marker, Popup, TileLayer, Polyline} from 'react-leaflet';
import {sendServerRequestWithBody} from "../../../api/restfulAPI";


export default class EditItinerary extends Component {
    constructor(props) {
        super(props);
        this.state={
            name: "",
            latitude: "",
            longitude: "",
            distances: [],
            newFile: "",
            errorMessage: null,
            tripName: ""
        };

        this.addToItinerary=this.addToItinerary.bind(this);
        this.updateName=this.updateName.bind(this);
        this.updateLatitude=this.updateLatitude.bind(this);
        this.updateLongitude=this.updateLongitude.bind(this);
    }


    render() {
        return (
            <Card> <CardBody>
                <Form>
                    <Row>
                        {this.newLocationInputField(this.updateName, this.state.name, 'Name')}
                        {this.newLocationInputField(this.updateLatitude, this.state.latitude, 'Latitude')}
                        {this.newLocationInputField(this.updateLongitude, this.state.longitude, 'Longitude')}
                    </Row>
                <br/>
                </Form >
                <Button onClick={this.addToItinerary} id='addPlace' className='btn-csu w-100'>Add</Button>
            </CardBody></Card>
        )
    }

    newLocationInputField(func, name, placeHolder){
        return(
            <Col xs={12} sm={12} md={5} lg={5} xl={4}>
                <Input onChange={func}
                   value={name}
                   placeholder={placeHolder}
                />
            </Col>
        );
    }

    updateName(event){
        this.setState({name: event.target.value});
    }
    updateLatitude(event){
        this.setState({latitude: event.target.value});
    }
    updateLongitude(event){
        this.setState({longitude: event.target.value});
    }
    addToItinerary(){
        if(this.state.name == "" || this.state.longitude == "" || this.state.latitude == ""){ return;}
        let newPlaces = this.props.options.places;
        var place = ({
           id: this.name,
           name: this.state.name.charAt(0).toUpperCase()+this.state.name.substr(1),
           latitude: this.state.latitude.toString(),
           longitude: this.state.longitude.toString()
        });
        newPlaces.push(this.props.convertCoordinate(place));
        this.resetState();
        this.props.updateDistances(newPlaces, this.props.settings.serverPort, this.props.options.options);
        this.props.updateMarkersAndLines(newPlaces, this.props.updateOption);
    }

    resetState(){
        this.setState({
            name: "",
            latitude: "",
            longitude: ""
        });
    }
}


