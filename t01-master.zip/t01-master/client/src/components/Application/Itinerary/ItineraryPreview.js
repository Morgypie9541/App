import React, {Component} from 'react';
import {Container, Row, Col} from 'reactstrap';
import { Button } from 'reactstrap';
import { Form, Label, Input, FormText, FormGroup } from 'reactstrap';
import { Card, CardHeader, CardBody} from 'reactstrap'
import { Table } from 'reactstrap'
import 'leaflet/dist/leaflet.css';
import { Map, Marker, Popup, TileLayer, Polyline} from 'react-leaflet';
import {sendServerRequestWithBody} from "../../../api/restfulAPI";


export default class ItineraryPreview extends Component {
    constructor(props) {
        super(props);
        this.state={
            //places: [],
            //distances: []
        }
    }


    render() {
        return (
            <Card className='text-center'style={{overflow:'auto'}} body outline color="secondary">
            <CardHeader className='bg-csu-gold text-white font-weight-semibold'>Itinerary Preview</CardHeader>
                <Button onClick={this.reverseItinerary.bind(this, this.props.options.places)} id="reverseItinerary" className='btn-csu'>Reverse</Button>
                <Button onClick={this.clearItinerary.bind(this)} id="clearItinerary" className='btn-csu'>Clear Itinerary</Button>
                    <CardBody>
                        <div style={{maxHeight:250}}>
                        <Table name='preview' responsive>
                        <thead>
                            <tr>
                                <th>Start</th>
                                <th>Distance to</th>
                                <th>End</th>
                                <th>Total</th>
                                <th>Edit</th>
                                <th size='sm' >Show Marker On Map <Button onClick={evt => this.clearMarkers()}>Clear</Button></th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.displayPlaces(this.props.options.places, this.props.options.distances, this.props.activeUnit)}
                        </tbody>
                    </Table></div>
                </CardBody>
            </Card>
        )
    }

    displayPlaces(places, distances, unit){
        if(this.props.distances != null) distances = this.props.distances;

        var dists = this.toFromDists(places, distances, unit);
        return dists.map((index, i) =>
            <tr>
                <td scope='row'>
                    {index.origin}
                </td>
                <td>
                    {index.distance}
                </td>
                <td>
                    {index.destination}
                </td>
                <td>
                    {index.totalDistance}
                </td>
                <td><Button onClick={evt => this.moveUp(i)}>&#8593;</Button>&nbsp;
                    <Button color="danger" onClick={evt => this.removePlace(i)}>-</Button>&nbsp;
                    <Button onClick={evt => this.moveDown(i)}>&#8595;</Button></td>
                <td><input type='button' id={i} key = {i} onClick={(e) => {this.props.signalCheckedBox(e.target.id)}}/></td>
            </tr>
        );
    }


    toFromDists(places, distances, unit){
        var ret = []
        var totDists = 0;

        if (places[0] == null){
            return ret;
        }
        else if(places.length == 1){
            distances[0] = "0";
            var leg = {
                origin: places[0].name,
                distance: '-',
                destination: '-',
                totalDistance: '-'
            }
            ret[0] = leg
            return ret

        }
        else {
            for(var i = 0; i < places.length; i++){
                var leg = {
                    origin: '',
                    distance: '',
                    destination: '',
                    totalDistance: ''
                }
                leg.origin = places[i].name;
                leg.distance = (distances[0] != null) ? distances[i] + " " + unit : '-';
                var next = (i == (places.length - 1)) ? 0 : i + 1
                leg.destination = places[next].name;
                totDists += distances[i];
                leg.totalDistance = (distances[0] != null) ? totDists + " " + unit : '-';
                ret[i] = leg;
            }
        }
        return ret;
    }

    reverseItinerary(places){
        if(this.props.places != null) places = this.props.places;
        var newPlaces = places.reverse();
        this.props.updateDistances(newPlaces, this.props.settings.serverPort, this.props.options.options);
        this.props.updateMarkersAndLines(newPlaces, this.props.updateOption);
    }

    clearItinerary(){
        const {places} = this.props.options;
        places.splice(0, places.length);
        this.updatePlaces(places);
        this.clearMarkers();
    }

    removePlace(i){
        const {places} = this.props.options;
        //deletes a check box if neccessary
        var includeMarkers = []
        if(this.props.view.includeMarkers != null) {
            includeMarkers = this.props.view.includeMarkers
        }
        if(places.length-1 == includeMarkers[includeMarkers.length-1]) {
            includeMarkers.pop()
            this.props.updateOption("includeMarkers",includeMarkers)
        }

        places.splice(i, 1);

        this.updatePlaces(places);
    }

    moveUp(i){
        if(i == 0) return false;
        this.swapPlaces(i, i-1);
    }

    moveDown(i){
        const {places} = this.props.options;
        if(i == places.length-1) return;
        this.swapPlaces(i, i+1);
    }

    swapPlaces(start, finish){
        const {places} = this.props.options;
        var temp = places[start];
        places[start] = places[finish];
        places[finish] = temp;
        this.updatePlaces(places);
    }

    updatePlaces(newPlaces){
        this.props.updateDistances(newPlaces, this.props.settings.serverPort, this.props.options.options);
        this.props.updateMarkersAndLines(newPlaces, this.props.updateOption);
    }
    clearMarkers() {
        var includeMarkers = []
        this.props.updateOption("includeMarkers",includeMarkers)

    }
}
