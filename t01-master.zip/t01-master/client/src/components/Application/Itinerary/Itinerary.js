import React, {Component} from 'react';
import {Container, Row, Col , ButtonGroup} from 'reactstrap';
import Pane from '../Pane';
import { Button } from 'reactstrap';
import { TabContent, TabPane, Nav, NavItem, NavLink, Form, Label, Input, FormText, FormGroup, Card, CardHeader,CardBody } from 'reactstrap';
import { Dropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import 'leaflet/dist/leaflet.css';
import { Map, Marker, Popup, TileLayer, Polyline} from 'react-leaflet';
import {sendServerRequestWithBody} from "../../../api/restfulAPI";
import ItineraryPreview from './ItineraryPreview';
import Coordinates from 'coordinate-parser';
import AddPlaces from './addPlaces'
import tokml from 'tokml';
import classnames from 'classnames';
import JSONSchemas from "../Misc/JSONSchemas";

//CREDIT:https://stackoverflow.com/questions/11257062/converting-json-object-to-csv-format-in-javascript?lq=1
function arrayToCSV(objArray) {
    const array = typeof objArray !== 'object' ? JSON.parse(objArray) : objArray;
    let header = `${Object.keys(array[0]).map(value => `"${value}"`).join(",")}` + '\n';

    return header + array.reduce((str, next) => {
        str += `${Object.values(next).map(value => `"${value}"`).join(",")}` + '\n';
        return str;
    }, '');
}

let savedState = {};

export default class Itinerary extends Component {
    constructor(props) {
        super(props);
        this.updateFileOnChange = this.updateFileOnChange.bind(this);
        this.createItinerary = this.createItinerary.bind(this);
        this.updateDistances = this.updateDistances.bind(this);
        this.togglebutton = this.togglebutton.bind(this);


        this.state = {
            options: {},
            places: [],
            distances:[],
            newFile:"",
            validFile: false,
            markers: [],
            lines:[],
            tripName:"Trip 1",
            errorMessage: null,
            optimization: 'None',
            includeMarkers:[],
            activeTab:"1",
            dropdownOpen: false
        };
        this.selectedOptimizationLevel = 'None';
    }

    componentDidMount(){
        this.setState(savedState);
    }

    componentWillUnmount() {
        savedState = this.state;
    }


    render() {
        return (
            <Container>
                <Row>
                    <Col xs={12} sm={12} md={7} lg={7} xl={8}>
                        {this.renderMap()}
                    </Col>
                    <Col xs={12} sm={12} md={5} lg={5} xl={4}>
                        {this.createItineraryUpload()}
                        {this.createOptimizeOptions()}
                    </Col>
                    <Col xs={12}>
                        <ItineraryPreview  options={this.state}
                                           view = {this.props.options}
                                           updateDistances={this.updateDistances}
                                           updateOption={this.props.updateOption}
                                           activeUnit={this.props.options.activeUnit}
                                           updateMarkersAndLines={this.updateMarkersAndLines}
                                           settings={this.props.settings}
                                           signalCheckedBox={this.signalCheckedBox}/>
                    </Col>&nbsp;
                    <Col xs={12}>
                        <AddPlaces  options={this.state}
                                    updateDistances={this.updateDistances}
                                    updateMarkersAndLines={this.updateMarkersAndLines}
                                    updateOption={this.props.updateOption}
                                    settings={this.props.settings}
                                    updateLines={this.updateMarkersAndLines}
                                    convertCoordinate={this.convertOneCoordinate}/>
                    </Col>
                </Row>
            </Container>
        )
    }

    togglebutton() {
        this.setState({
            dropdownOpen: !this.state.dropdownOpen
        });
    }

    createOptimizeOptions(){
        return (
            <Pane header={'Trip Options'}
                  bodyJSX={
                      <div style={{height:'auto'}}>
                          <h5>{'Calculate Distances:'}</h5>
                          <Button id='create' name='uploadFile' onClick={this.createItinerary}>Calculate Distances</Button>
                          <h5>{'Choose level of Optimization'}</h5>
                            {this.optimizeButton('None')}&nbsp;
                            {this.optimizeButton('Short')}&nbsp;
                      </div>}
            />);

    }

    optimizeButton(opt){
            return(
                <Button id={opt} name={opt} onClick={(event) => {this.optimizationClick(event.target.name)}}> {opt} </Button>
            );
    }


    optimizationClick(name){
        this.state.options.optimization = name;
        this.createItinerary();
    }
    toggle(tab){
        if(this.state.activeTab !== tab){
            this.setState({
                activeTab: tab
            });
        }
    }
    createItineraryUpload(){
        let updateFile= (event)=>{
            this.updateFileOnChange('file', event.target.files[0])
        };

        if(this.state.tripName == null) { this.state.tripName = "Trip 1"};
        return (
            <Pane header = {this.state.tripName}
                  bodyJSX={
                    <Card className='text-center'style={{overflow:'auto'}} body outline color="secondary">
                        <CardBody>
                              <Nav tabs>
                                  <NavItem>
                                      <NavLink
                                          className={classnames({ active: this.state.activeTab === '1' })}
                                          onClick={() => { this.toggle('1'); }}>
                                          Load
                                      </NavLink>
                                  </NavItem>
                                  <NavItem>
                                      <NavLink
                                          className={classnames({ active: this.state.activeTab === '2' })}
                                          onClick={() => { this.toggle('2'); }}>
                                          Save
                                      </NavLink>
                                  </NavItem>
                              </Nav>
                              <TabContent activeTab={this.state.activeTab}>
                              <TabPane tabId="1">
                                  <Form>
                                      <FormGroup>
                                          <h5>Load Itinerary:</h5>
                                          <Input type="file"
                                                 name="itineraryFile"
                                                 id='fileHandler'
                                                 onChange={updateFile}/>
                                          <FormText color="muted">
                                              JSON file(.json).
                                          </FormText>
                                      </FormGroup>

                                      <p><font color="red" id='fileError'> </font></p>
                                  </Form>
                              </TabPane>
                              <TabPane tabId="2">
                                  <div style={{height:'auto'}}>
                                      <h5>Save Itinerary:</h5>
                                      <Dropdown isOpen={this.state.dropdownOpen} toggle={this.togglebutton}>
                                          <DropdownToggle caret>
                                              Save As
                                          </DropdownToggle>
                                          <DropdownMenu>
                                              <DropdownItem onClick={this.saveNewFile.bind(this,this.state.tripName.concat('.json'), this.state.newFile)}>JSON</DropdownItem>
                                              <DropdownItem onClick={this.saveItineraryCSV.bind(this,this.state.tripName.concat('.csv'), this.state.places)}>CSV</DropdownItem>
                                              <DropdownItem onClick={this.saveItineraryKML.bind(this,this.state.tripName.concat('.kml'), this.state.places)}>KML</DropdownItem>
                                          </DropdownMenu>
                                      </Dropdown>
                                      <p><font color="red" id="saveERR"></font></p>
                                  </div>
                              </TabPane>
                              </TabContent>
                        </CardBody>
                    </Card>}
            />
        );
    }

    createItinerary(){
        if(this.state.validFile==false  && this.state.places == null && this.props.options.places == null){
            document.getElementById('fileError').innerHTML = "ERR: Incorrect file type. Must be .json.";
            return;
        }
        if(this.state.optimization == null) this.state.optimization = "None";
        document.getElementById('fileError').innerHTML="";
        const tipConfigRequest={
          'requestType'        : 'itinerary',
          'requestVersion'     : 5,
          'options'     : this.state.options,
          'places'      : this.convertCoordinates(this.state.places)
        };
        sendServerRequestWithBody('itinerary',tipConfigRequest, this.props.settings.serverPort)
            .then((response)=>{
            if(response.statusCode >= 200 && response.statusCode <=299) {
                if (JSONSchemas.ValidateItinerarySchema(response.body)) {
                    this.setState({
                        distances: response.body.distances,
                        newFile: JSON.stringify(response.body),
                        tripName: response.body.options.title,
                        places: response.body.places,
                        errorMessage: null
                    });
                    this.updateDistances(response.body.places, this.props.settings.serverPort, this.state.options);
                    this.updateMarkersAndLines(response.body.places, this.props.updateOption);
                }
                else{
                    this.setState({
                        errorMessage: this.props.createErrorBanner(
                            "Error",
                            400,
                            `Response from ${this.props.settings.serverPort} failed. The server has failed, please
                            Call Will McDonald at 208-684-2233 for technical support.`
                        )
                    });
                }
            }
            else{
                this.setState({
                    errorMessage: this.props.createErrorBanner(
                        response.statusText,
                        response.statusCode,
                        `Request to ${ this.props.settings.serverPort } failed.`
                    )
                });
            }
            });
    }


    saveItineraryCSV(filename, places){
        if(!places){
            document.getElementById("saveERR").innerHTML="ERR: Please Add to Itinerary First.";
            return;
        }
        else{
            var data = arrayToCSV(places);
            var blob = new Blob([data], {type: 'csv'});
            this.downloadCheck(blob,filename)
        }
    }
    saveItineraryKML(filename, places){
        if(!places){
            document.getElementById("saveERR").innerHTML="ERR: Please Add to Itinerary First.";
            return;
        }else{
            var geojson = {
                type: "FeatureCollection",
                features: [],
            };

            for (var i = 0; i < places.length; i++) {

                geojson.features.push({
                    "type": "Feature",
                    "geometry": {
                        "type": "Point",
                        "coordinates": [places[i].longitude, places[i].latitude]
                    },
                    "properties": {
                        "name": [places[i].name]
                    }});
            }

            var kml = tokml(geojson);
            var blob = new Blob([kml], {type: 'kml'});
            this.downloadCheck(blob,filename)
        }
    }

    //CREDIT:https://stackoverflow.com/questions/3665115/create-a-file-in-memory-for-user-to-download-not-through-server/18197341?noredirect=1#answer-3665147
    saveNewFile(filename, data){
        if(data==""){
            document.getElementById("saveERR").innerHTML="ERR: To download a JSON file, please upload itinerary first.";
            return;}
        else{
            var blob = new Blob([data], {type: 'json'});
            this.downloadCheck(blob,filename)
        }
    }
    downloadCheck(blob,filename){
        if(window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveBlob(blob, filename);
        }
        else{
            var elem = window.document.createElement('a');
            elem.href = window.URL.createObjectURL(blob);
            elem.download = filename.replace(" ","");
            document.body.appendChild(elem);
            elem.click();
            document.body.removeChild(elem);
        }
    }

    renderMap() {
        return (
            <Pane header={this.state.tripName}
                  bodyJSX={this.renderLeafletMap()}/>
        );
    }

    renderLeafletMap() {
        // initial map placement can use either of these approaches:
        // 1: bounds={this.coloradoGeographicBoundaries()}
        // 2: center={this.csuOvalGeographicCoordinates()} zoom={10}
        var places = (this.props.options.places == null) ? this.state.places : this.props.options.places;
        var distances = (this.props.options.distances == null) ? this.state.distances : this.props.options.distances;
        var lines = (this.props.options.lines == null) ? this.state.lines : this.props.options.lines;
        var markers = (this.props.options.markers == null) ? this.state.markers : this.props.options.markers;
        var mask = (this.props.options.includeMarkers == null) ? this.state.includeMarkers: this.props.options.includeMarkers
        //select the corerct markers based on the array includeMarkers
        var newMarkers = []
        var markerNames = []
        for(var i = 0; i<mask.length; i++){
            newMarkers.push(markers[mask[i]])
            markerNames.push(places[mask[i]].name)
        }
        return (

                <Map name='itineraryMap' bounds={this.mapBounds()} zoom={10}
                     style={{height: 500, maxwidth: 700}}>
                     <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                           attribution="&copy; <a href=&quot;http://osm.org/copyright&quot;>OpenStreetMap</a> contributors"
                    />
                    {newMarkers.map((position, idx) =>
                        <Marker key={`marker-${idx}`} position={position} icon={this.markerIcon()}>
                            <Popup className="font-weight-extrabold">{markerNames[idx]}</Popup>
                        </Marker>)}
                    {lines.map((positions, idx) =>
                        <Polyline key={`polyline-${idx}`} positions={positions} color='blue'>
                            <Popup className="font-weight-extrabold">{((distances) == []) ? '--' : distances[idx]}  {this.props.options.activeUnit}</Popup>
                        </Polyline>)}
                </Map>
        )
    }

    mapBounds() {

        var places = this.props.options.places;
        // will default to show the whole world
        if(places == null || (places.length == 2 && places[0].latitude == places[1].latitude && places[0].longitude == places[1].longitude)){
            return L.latLngBounds(L.latLng(80, -170), L.latLng(-80, 170));
        }
        else{
            if(places.length <= 1) {
                return L.latLngBounds(L.latLng(80, -170), L.latLng(-80, 170));
            }else{
                //find starting bounds
                var bounds = L.latLngBounds( L.latLng(places[0].latitude,places[0].longitude), L.latLng(places[1].latitude,places[1].longitude));
                //extend the bounds
                for(var i = 2 ; i <places.length; i++){
                    bounds.extend(L.latLng(places[i].latitude,places[i].longitude))
                }
                return bounds
            }

        }

    }

    signalCheckedBox(id){
        var includeMarkers = []
        if(this.view.includeMarkers != null){
            includeMarkers = this.view.includeMarkers
        }
        //dont add a duplicate
        var indexOf = includeMarkers.indexOf(id)
        if( indexOf == -1){
            includeMarkers.push(id)
        }else if(includeMarkers[indexOf] == id){
            includeMarkers.splice(indexOf,1)
        }
        this.updateOption("includeMarkers",includeMarkers)

    }

    convertOneCoordinate(place){
        var newPlace = new Coordinates(place.latitude + ' ' + place.longitude);
        place.latitude = newPlace.getLatitude().toString();
        place.longitude = newPlace.getLongitude().toString();
        return place
    }

    convertCoordinates(places){
        for(var i = 0; i < places.length; i++) {
            places[i] = this.convertOneCoordinate(places[i]);
        }
        this.setState({places: 'places'});
        this.props.updateOption('places', places);
        return places;
    }

    coloradoGeographicBoundaries() {
        // northwest and southeast corners of the state of Colorado
        return L.latLngBounds(L.latLng(41, -109), L.latLng(37, -102));
    }

    csuOvalGeographicCoordinates() {
        return L.latLng(40.576179, -105.080773);
    }

    markerIcon() {
        // react-leaflet does not currently handle default marker icons correctly,
        // so we must create our own
        return L.icon({
            iconUrl: icon,
            shadowUrl: iconShadow,
            iconAnchor: [12, 40]  // for proper placement
        })
    }

    updateDistances(newPlaces, serverPort, options){
        if(options.earthRadius == null) options.earthRadius = "3959" //default to miles
        const tipConfigRequest={
            'requestType'        : 'itinerary',
            'requestVersion'     : 5,
            'options'     : options,
            'places'      : newPlaces
        }


        sendServerRequestWithBody('itinerary',tipConfigRequest, serverPort).then((response)=>{
            if(response.statusCode >= 200 && response.statusCode <=299){
                //this.updateOption('distances', response.body.distances);
                this.props.updateOption('distances', response.body.distances);
                this.setState({distances: response.body.distances});
            }
        });

       this.props.updateOption('places', newPlaces);
    }


    updateMarkersAndLines(places, func){
        const markers = [];
        const lines = [];
        if (places.length > 1) {
            for (var i = 0; i < places.length; i++) {
                var t2 = [];
                if (i == places.length - 1) {
                    t2 = [
                        [parseFloat(places[i].latitude), parseFloat(places[i].longitude)],
                        [parseFloat(places[0].latitude), parseFloat(places[0].longitude)]
                    ];
                }
                else {
                    t2 = [
                        [parseFloat(places[i].latitude), parseFloat(places[i].longitude)],
                        [parseFloat(places[i + 1].latitude), parseFloat(places[i + 1].longitude)]
                    ];
                }
                markers.push(L.latLng(places[i].latitude, places[i].longitude));
                lines.push(t2);
            }
        }
        else if(places.length != 0){
            markers.push(L.latLng(places[0].latitude, places[0].longitude));
        }
        func('markers', markers);
        func('lines', lines);
    }

    updateFileOnChange(stateVar, value){
        var fileInput= value;
        var textType= /json.*/;
        if(fileInput.type.match(textType)){
            var r= new FileReader();
            var temp=null;
            var ready=false;
            this.setState({
                markers: [],
                distances: [],
                lines: []
            });
    //CREDIT:https://stackoverflow.com/questions/17068610/read-a-file-synchronously-in-javascript
            var check = function() {
                if (ready === true) {
                    this.setState({
                        options: temp.options,
                        places: this.convertCoordinates(temp.places),
                        validFile: true
                    });
                    const {markers} = this.state;
                    const {lines}=this.state;
                    var i = 0;
                    for(; i < this.state.places.length; i++){
                        var t2=[];
                        if(i==this.state.places.length-1){
                            t2=[
                                [parseFloat(this.state.places[i].latitude), parseFloat(this.state.places[i].longitude)],
                                [parseFloat(this.state.places[0].latitude), parseFloat(this.state.places[0].longitude)]
                            ];
                        }
                        else{
                            t2=[
                                [parseFloat(this.state.places[i].latitude), parseFloat(this.state.places[i].longitude)],
                                [parseFloat(this.state.places[i+1].latitude),parseFloat(this.state.places[i+1].longitude)]
                            ];
                        }

                        markers.push(L.latLng(this.state.places[i].latitude, this.state.places[i].longitude));
                        lines.push(t2);
                    }
                    this.setState({markers});
                    this.setState({lines});
                    return;
                }
                setTimeout(check, 1000);
            }.bind(this);
            check();
            r.onload= function(e){
                temp=JSON.parse(e.target.result);
                ready=true;
                return;
            };
            r.readAsText(fileInput);
        }
        else{
            document.getElementById('Itinerary Preview').innerHTML="";
            this.setState({
                options: {},
                places: [],
                validFile: false,
                tripName: "No Trip Created Yet"
            })
        }
    }
}
