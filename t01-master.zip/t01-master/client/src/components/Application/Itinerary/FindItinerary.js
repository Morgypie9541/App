import React, {Component} from 'react';
import {Container, Row, Col} from 'reactstrap';
import { Button, ButtonGroup,Card, CardHeader, CardBody, Alert} from 'reactstrap';
import { Form, Label, Input, FormText, FormGroup } from 'reactstrap';
import { Table } from 'reactstrap'
import Select from 'react-select';
import {countries,portTypes} from "./data";
import {sendServerRequestWithBody} from "../../../api/restfulAPI";
import JSONSchemas from "../Misc/JSONSchemas";

export default class FindItinerary extends Component {
    constructor(props) {
        super(props);
        this.state={
            places : [],
            match : "",
            limit: 100,
            found : null,
            popoverOpen: false,
            popoverOpen2:false,
            cSelected: [],
            selectedOption:[],
            tags:[],
            errorMessage: null

        };
        this.displayFoundPlaces=this.displayFoundPlaces.bind(this);
        this.updateMatch=this.updateMatch.bind(this);
        this.searchDB=this.searchDB.bind(this);
        this.addToItinerary=this.addToItinerary.bind(this);
        this.toggle=this.toggle.bind(this);
        this.toggle2=this.toggle2.bind(this);
        this.handleChange=this.handleChange.bind(this);
        this.handleChange2=this.handleChange2.bind(this);
    }

    render() {
        return (
            <div style={{maxHeight:250}}>
        <Card > <CardBody>
            <Form onSubmit={this.gotInput}>
                    <Row>
                        <Col xs={12} sm={12} md={5} lg={5} xl={4}>
                            <Input      name="searchField"
                                        onChange={this.updateMatch}
                                        value={this.state.match}
                                        placeholder={'Name'}
                            />
                        </Col>

                        <Col xs={12} sm={12} md={5} lg={5} xl={4}>
                            <Button type='button' color='primary' onClick={this.searchDB} id='searchPlaces'>Search</Button>
                            <Alert color="danger" isOpen={this.state.popoverOpen} toggle={this.toggle}>
                                SQL injections are NOT ALLOWED!
                            </Alert>
                            <Alert color="danger" isOpen={this.state.popoverOpen2} toggle={this.toggle2}>
                                Place already exists in current Itinerary!
                            </Alert>
                        </Col>
                    </Row>

                    <Row>
                        <h5>Filter Results by...</h5>
                    </Row>
                    <Row>
                        {this.createSelects(this.state.cSelected,portTypes,this.handleChange2)}
                        {this.createSelects(this.state.selectedOption,countries,this.handleChange)}
                    </Row>

                </Form >
        </CardBody></Card>
        {this.displayFoundPlaces()} </div>

    )
    }

    createSelects(value,data,onchange){
        let name="";
        if(data===countries)
            name="Countries";
        else
            name="Port Type";
        return(
            <Col xs={12} sm={12} md={5} lg={5} xl={4}>
                <p>{name}:</p>
            <Select
            menuPlacement="top"
            value={value}
            isMulti
            name={name}
            placeholder={"Search "+name+"..."}
            options={data}
            onChange={onchange}
            className="basic-multi-select"
            classNamePrefix="select"
        />
            </Col>);
    }

    handleChange(selectedOption){
        this.setState({ selectedOption });
    }
    handleChange2(cSelected){
        this.setState({ cSelected });
    }

    toggle(){
        this.setState({popoverOpen:false});
    }
    toggle2(){
        this.setState({popoverOpen2:false});
    }

    gotInput(event){
        event.preventDefault();
    }

    searchDB(){
        if(this.state.match==""){return;}
        else if(this.state.match.match(/;/)) {
            this.setState({popoverOpen:true});
            return;
        }
        const tipConfigRequest={
            'requestType'        : 'find',
            'requestVersion'     : 5,
            'limit'        :this.state.limit,
            'match'     : this.state.match.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>{}\[\]\\\/]/gi, '_'),
            'narrow'   :[{"name":"type", "values":this.state.cSelected.map(obj => Object.values(obj)[0])},{"name":"country", "values":this.state.selectedOption.map(obj => Object.values(obj)[0])}]
        };
        sendServerRequestWithBody('find',tipConfigRequest, this.props.settings.serverPort)
            .then((response)=>{
                if(response.statusCode >= 200 && response.statusCode <=299) {
                    if (JSONSchemas.ValidateFindSchema(response.body)) {
                        this.setState({
                            places: response.body.places,
                            found: response.body.found
                        });
                    } else {
                        this.setState({
                            errorMessage: this.props.createErrorBanner(
                                "Error",
                                400,
                                `Response from ${this.props.settings.serverPort} failed. The server has failed, please
                            Call Will McDonald at 208-684-2233 for technical support.`
                            )
                        });
                    }
                }
                else{
                    this.setState({
                        errorMessage: this.props.createErrorBanner(
                            response.statusText,
                            response.statusCode,
                            `Request to ${ this.props.settings.serverPort } failed.`)}); }
            });
    }

    updateMatch(event){
        this.setState({match: event.target.value});
    }

    displayFoundPlaces(){
        if(this.state.found==null || this.state.found==0){
            return;
        }
        return(
            <div>
                <Label for='foundPlaces'>Found {this.state.found}. Showing {this.state.places.length} of {this.state.found}.</Label>
            <Table name='foundPlaces' responsive>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Region</th>
                    <th>Country</th>
                    <th>Add?</th>
                </tr>
                </thead>
                <tbody>
                    {this.displaySearchResults()}
                </tbody>
            </Table>
            </div>
        )
    }

    displaySearchResults(){
        var locations= this.createLocationMap();
        return locations.map((name,value)=>
            <tr key={value}>
                <td scope='row'>
                    {name.name}
                </td>
                <td>
                    {name.region}
                </td>
                <td>
                    {name.country}
                </td>
                <td>
                    <Button type='button' color="primary" onClick={()=>{this.addToItinerary(name.name, name.lat, name.lon)}} id={"addPlace_"+value}>Add</Button>
                </td>
            </tr>
        );
    }

    createLocationMap(){
        var final=[];
        for(var i=0; i<this.state.places.length;++i){
            var local={
                name: '',
                lat: '',
                lon: '',
                region: '',
                country: ''
            };
            local.name= this.state.places[i].name;
            local.lat = this.state.places[i].latitude;
            local.lon = this.state.places[i].longitude;
            local.region= this.state.places[i].region;
            local.country=this.state.places[i].country;
            final[i]=local;
        }
        return final;
    }

    addToItinerary(name, lat, long){
        if(this.props.options.places.filter(function(e){
            return e.name === name;}).length > 0){
            this.setState({popoverOpen2:true});
            return;
        }
        else{
           let newPlaces=this.props.options.places;
           newPlaces.push({
              id: this.name,
              name: name,
              latitude: parseInt(lat, 10).toString(),
              longitude: parseInt(long, 10).toString()
           });
            if(this.props.options.options.earthRadius == null) this.props.options.options.earthRadius = "3959"; //defaults to miles
            const tipConfigRequest={
                'requestType'        : 'itinerary',
                'requestVersion'     : 5,
                'options'     : this.props.options.options,
                'places'      : newPlaces
            };

            sendServerRequestWithBody('itinerary',tipConfigRequest, this.props.settings.serverPort)
                .then((response)=>{
                    if(response.statusCode >= 200 && response.statusCode <=299){
                        this.props.updateOption('distances', response.body.distances);
                    }
                });

            this.props.updateOption('places', newPlaces);
            this.updatePlaces(newPlaces);
        }
    }

    updatePlaces(newPlaces){
        this.props.updateDistances(newPlaces, this.props.settings.serverPort, this.props.options.options);
        this.props.updateMarkersAndLines(newPlaces, this.props.updateOption);
    }
}