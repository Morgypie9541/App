import React, {Component} from 'react';
import { TabContent, TabPane, Nav, NavItem, NavLink, Card, Button, CardTitle, CardText, Row, Col } from 'reactstrap';
import {Container} from 'reactstrap';
import { Form, Label, Input, FormText, FormGroup } from 'reactstrap';
import { CardHeader, CardBody} from 'reactstrap'
import { Table } from 'reactstrap'
import 'leaflet/dist/leaflet.css';
import { Map, Marker, Popup, TileLayer, Polyline} from 'react-leaflet';
import {sendServerRequestWithBody} from "../../../api/restfulAPI";
import classnames from 'classnames';
import EditItinerary from './EditItinerary';
import FindItinerary from './FindItinerary';

// Code for this file was made based on code at this url: https://reactstrap.github.io/components/tabs/
export default class AddPlaces extends Component {
    constructor(props) {
        super(props);
        this.toggle = this.toggle.bind(this);
        this.state = {
            activeTab: "1"
        };
    }

    render() {
        return (
            <Card className='text-center'style={{overflow:'auto'}} body outline color="secondary">
            <CardHeader className='bg-csu-gold text-white font-weight-semibold'>Add New Place</CardHeader>
            <CardBody>
                <Nav tabs>
                    {this.createOption('1', 'Search')}
                    {this.createOption('2', 'Add Manually')}
                </Nav>
                    {this.callPages()}
            </CardBody>
            </Card>
        )
    }

    createOption(tab, name){
        return(
            <NavItem>
                <NavLink
                    className={classnames({ active: this.state.activeTab === tab })}
                    onClick={() => { this.toggle(tab); }}>
                    {name}
                </NavLink>
            </NavItem>
        );
    }

    callPages(){
    return (<TabContent activeTab={this.state.activeTab}>
                <TabPane tabId="1">
                    <Row>
                        <Col xs='12' sm="12">
                        <FindItinerary  options={this.props.options}
                        updateDistances={this.props.updateDistances}
                        updateMarkersAndLines={this.props.updateMarkersAndLines}
                        updateOption={this.props.updateOption}
                        settings={this.props.settings}
                        updateLines={this.props.updateMarkersAndLines}/>
                        </Col>
                    </Row>
                </TabPane>
                <TabPane tabId="2">
                    <Row id='editItinerary'>
                        <Col sm="12">
                        <EditItinerary  options={this.props.options}
                        updateDistances={this.props.updateDistances}
                        updateOption={this.props.updateOption}
                        settings={this.props.settings}
                        updateMarkersAndLines={this.props.updateMarkersAndLines}
                        convertCoordinate={this.props.convertCoordinate}/>
                        </Col>
                    </Row>
                </TabPane>
            </TabContent>);
    }

    toggle(tab){
        if(this.state.activeTab !== tab){
            this.setState({
                activeTab: tab
            });
        }
    }
}