import React, {Component} from 'react';
import {Card, CardBody, CardHeader, Container} from 'reactstrap';

import Home from './Home';
import About from './AboutUs/AboutUs';
import Itinerary from './Itinerary/Itinerary';
import Options from './Options/Options';
import Calculator from './Calculator/Calculator';
import Settings from './Settings/Settings';
import {getOriginalServerPort, sendServerRequest} from '../../api/restfulAPI';
import ErrorBanner from './ErrorBanner';
import {getSavedUnits} from './Cookies';
import JSONSchemas from "./Misc/JSONSchemas";


/* Renders the application.
 * Holds the destinations and options state shared with the trip.
 */
export default class Application extends Component {
  constructor(props){
    super(props);

    this.updatePlanOption = this.updatePlanOption.bind(this);
    this.updateCalc=this.updateCalc.bind(this);
    this.updateClientSetting = this.updateClientSetting.bind(this);
    this.createApplicationPage = this.createApplicationPage.bind(this);

    this.state = {
      serverConfig: null,
      planOptions: {
        units: getSavedUnits(),
        activeUnit: 'miles'
      },
      calculatorSettings:{
          origin: {latitude: '', longitude: ''},
          destination: {latitude: '', longitude: ''},
          distance: 0,
      },
      clientSettings: {
        serverPort: getOriginalServerPort()
      },
      errorMessage: null
    };

    this.updateServerConfig();
  }

  render() {
    let pageToRender = this.state.serverConfig ? this.props.page : 'settings';

    return (
      <div className='application-width'>
        { this.state.errorMessage }{ this.createApplicationPage(pageToRender) }
      </div>
    );
  }

  updateClientSetting(field, value) {
    if(field === 'serverPort')
      this.setState({clientSettings: {serverPort: value}}, this.updateServerConfig);
    else {
      let newSettings = Object.assign({}, this.state.planOptions);
      newSettings[field] = value;
      this.setState({clientSettings: newSettings});
    }
  }

  updatePlanOption(option, value) {
    if(option === 'activeUnit'){
      let newDistance = Object.assign({}, this.state.calculatorSettings);
      newDistance['distance'] = 0;
      this.setState({calculatorSettings: newDistance});
    }
    /*let optionsCopy = Object.assign({}, this.state.planOptions);
    optionsCopy[option] = value;
    this.setState({'planOptions': optionsCopy});*/
    let optionsCopy = Object.assign({}, this._planOptions || this.state.planOptions);
    optionsCopy[option] = value;
    this._planOptions = optionsCopy;
    this.setState({planOptions: optionsCopy});
  }

  updateCalc(value){
    this.setState({calculatorSettings: value});
  }

  updateServerConfig() {
    sendServerRequest('config', this.state.clientSettings.serverPort).then(config => {
      console.log(config);
      this.processConfigResponse(config);
    });
  }

  createErrorBanner(statusText, statusCode, message) {
    return (
      <ErrorBanner statusText={statusText}
                   statusCode={statusCode}
                   message={message}/>
    );
  }

  createApplicationPage(pageToRender) {
    switch(pageToRender) {
      case 'about':
          return <About />;
      case 'itinerary':
          return <Itinerary options={this.state.planOptions}
                            settings={this.state.clientSettings}
                            updateOption={this.updatePlanOption}
                            createErrorBanner={this.createErrorBanner}/>;
      case 'calc':
        return <Calculator options={this.state.planOptions}
                           settings={this.state.clientSettings}
                           calculator={this.state.calculatorSettings}
                           updateCalculator={this.updateCalc}
                           createErrorBanner={this.createErrorBanner}/>;
      case 'options':
        return <Options options={this.state.planOptions}
                        config={this.state.serverConfig}
                        updateOption={this.updatePlanOption}/>;
      case 'settings':
        return <Settings options={this.state.planOptions}
                         updateOption={this.updatePlanOption}
                         settings={this.state.clientSettings}
                         serverConfig={this.state.serverConfig}
                         updateSetting={this.updateClientSetting}/>;
      default:
        return <Home/>;
    }
  }

  processConfigResponse(config) {
    if(config.statusCode >= 200 && config.statusCode <= 299) {
      if(JSONSchemas.ValidateConfigSchema(config.body)) {
      console.log("Switching to server ", this.state.clientSettings.serverPort);
      this.setState({
        serverConfig: config.body,
        errorMessage: null
      });
    }
      else{
        this.setState({
          errorMessage: this.props.createErrorBanner(
              "Error",
              400,
              `Response from ${this.props.settings.serverPort} failed.`
          )
        });
      }
      }
    else {
      this.setState({
        serverConfig: null,
        errorMessage:
          <Container>
            {this.createErrorBanner(config.statusText, config.statusCode,
            `Failed to fetch config from ${ this.state.clientSettings.serverPort}. Please choose a valid server.`)}
          </Container>
      });
    }
  }
}
