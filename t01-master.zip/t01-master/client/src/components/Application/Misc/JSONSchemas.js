
import Ajv from 'ajv';

export default class JSONSchemas{

    static ValidateConfigSchema(value){
        let schema = {
                "$id": "https://example.com/address.schema.json",
                "$schema": "http://json-schema.org/draft-07/schema#",
                "title": "config",
                "description": "config response",
                "type": "object",
                "definitions": {
                    "filter": {
                        "type":"object",
                        "description": "name and list of values to filter by",
                        "properties": {
                            "name": {
                                "type":"string",
                                "not": {
                                    "enum": ["type"]
                                },
                                "minLength": 1
                            },
                            "values": {
                                "type":"array",
                                "items": {
                                    "type":"string",
                                    "minLength":1
                                },
                                "uniqueItems": true
                            }
                        },
                        "required": ["name", "values"]
                    },
                    "nameFilter": {
                        "type": "object",
                        "description": "the filter that is required",
                        "properties": {
                            "name": {
                                "type": "string",
                                "enum": ["type"]
                            },
                            "values": {
                                "type":"array",
                                "items": {
                                    "type":"string",
                                    "minLength":1
                                },
                                "required": ["airport", "heliport", "balloonport", "closed"],
                                "uniqueItems": true
                            }
                        },
                        "required": ["name", "values"]
                    }
                },
                "properties": {
                    "requestVersion": {
                        "description":"the TIP protocol version",
                        "type":"integer",
                        "minimum": 1
                    },
                    "requestType": {
                        "description":"the TIP object type should be config",
                        "type":"string",
                        "pattern":"^config$"
                    },
                    "serverName": {
                        "description":"identify the server instance",
                        "type":"string",
                        "minLength":3
                    },
                    "placeAttributes": {
                        "description":"list of attributes used to described places",
                        "type":"array",
                        "items": {
                            "type":"string"
                        },
                        "minItems":9,
                        "uniqueItems": true,
                        "required":["name", "latitude", "longitude", "id", "municipality", "region", "country", "continent", "altitude"]
                    },
                    "optimizations": {
                        "description":"list of optimization levels available from the server",
                        "type":"array",
                        "items": {
                            "type":"string",
                            "minLength":1
                        },
                        "minItems":2,
                        "uniqueItems": true,
                        "required":["none", "short"]
                    },
                    "filters": {
                        "description":"list describing one or more filters that may be applied to finds on the server",
                        "type":"array",
                        "items": {
                            "oneOf": [
                                {"$ref": "#/definitions/nameFilter"},
                                {"$ref": "#/definitions/filter"}
                            ]
                        },
                        "contains": {"$ref": "#/definitions/nameFilter"},
                        "minItems":1,
                        "uniqueItems": true
                    }
                },
                "required":["requestVersion","requestType","serverName","placeAttributes","optimizations","filters"],
                "additionalProperties": false
            };

        let ajv = new Ajv({allErrors:true});
        const validator = ajv.compile(schema);
        let v = validator(value);
        return v;
    }

    static ValidateDistanceSchema(value){
        let schema = {
        "$id": "https://example.com/address.schema.json",
            "$schema": "http://json-schema.org/draft-07/schema#",
            "title": "distance",
            "description": "distance request/response",
            "type": "object",
            "properties": {
            "requestVersion": {
                "description":"the TIP protocol version",
                    "type":"integer",
                    "minimum": 1
            },
            "requestType": {
                "description":"the TIP object type should be distance",
                    "type":"string",
                    "pattern":"^distance$"
            },
            "origin":{
                "description":"an object with the attributes to describe a place",
                    "type": "object",
                    "properties": {
                    "name":{"type":"string"},
                    "latitude":{"type":"string",
                        "pattern":"^[-+]?(?:90(?:(?:\\.0+)?)|(?:[0-9]|[1-8][0-9])(?:(?:\\.[0-9]+)?))$"},
                    "longitude":{"type":"string",
                        "pattern":"^[-+]?(?:180(?:(?:\\.0+)?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\\.[0-9]+)?))$"}
                },
                "required":["latitude","longitude"],
                    "additionalProperties":true
            },
            "destination":{
                "description":"an object with the attributes to describe a place",
                    "type": "object",
                    "properties": {
                    "name":{"type":"string"},
                    "latitude":{"type":"string",
                        "pattern":"^[-+]?(?:90(?:(?:\\.0+)?)|(?:[0-9]|[1-8][0-9])(?:(?:\\.[0-9]+)?))$"},
                    "longitude":{"type":"string",
                        "pattern":"^[-+]?(?:180(?:(?:\\.0+)?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\\.[0-9]+)?))$"}
                },
                "required":["latitude","longitude"],
                    "additionalProperties":true
            },
            "earthRadius":{
                "description":"the radius of the earth in some unit of measure",
                    "type":"number",
                    "exclusiveMinimum":0
            },
            "distance":{
                "description":"the great circle distance between the origin and destination using the radius measure",
                    "type":"integer",
                    "minimum":0
            }
        },
        "required":["requestVersion","requestType","origin","destination","earthRadius"],
            "additionalProperties": false
    };

        let ajv = new Ajv({allErrors:true});
        const validator = ajv.compile(schema);
        let v = validator(value);
        return v;
    }

    static ValidateItinerarySchema(value){
      let schema = {
              "$id": "https://example.com/address.schema.json",
              "$schema": "http://json-schema.org/draft-07/schema#",
              "title": "itinerary",
              "description": "itinerary request/response",
              "type": "object",
              "properties": {
                  "requestVersion": {
                      "description":"the TIP protocol version",
                      "type":"integer",
                      "minimum": 2
                  },
                  "requestType": {
                      "description":"the TIP object type should be itinerary",
                      "type":"string",
                      "pattern":"^itinerary$"
                  },
                  "options": {
                      "description":"options for this request",
                      "type":"object",
                      "properties": {
                          "title": {"type":"string"},
                          "earthRadius": {"type":"string", "pattern":"^[0-9]+(\\.[0-9]+)?$"},
                          "optimization": {"type":"string"}
                      },
                      "required":["earthRadius"]
                  },
                  "places": {
                      "description": "list of places to visit",
                      "type":"array",
                      "items": {
                          "type":"object",
                          "properties": {
                              "name": {"type":"string"},
                              "latitude": {"type":["string","number"]},
                              "longitude": {"type":["string","number"]},
                              "id": {"type":["integer","string"]},
                              "municipality": {"type":"string"},
                              "altitude": {"type":"string", "pattern":"^[0-9]+(.[0-9]*)$"}
                          },
                          "required": ["latitude","longitude"],
                          "additionalProperties": true
                      },
                      "minitems": 0
                  },
                  "distances": {
                      "description": "distances between corresponding places",
                      "type":"array",
                      "items": {
                          "type":"integer"
                      },
                      "minitems": 0
                  }
              },
              "required":["requestVersion","requestType","options","places"],
              "additionalProperties": false
          };

        let ajv = new Ajv({allErrors:true});
        const validator = ajv.compile(schema);
        let v = validator(value);
        return v;
    }
    static ValidateFindSchema(value){
        let schema = {
            "$id": "https://example.com/address.schema.json",
            "$schema": "http://json-schema.org/draft-07/schema#",
            "title": "itinerary",
            "description": "itinerary request/response",
            "type": "object",
            "properties": {
                "requestVersion": {
                    "description":"the TIP protocol version",
                    "type":"integer",
                    "minimum": 3
                },
                "requestType": {
                    "description":"the TIP object type should be itinerary",
                    "type":"string",
                    "pattern":"^find$"
                },
                "match": {
                    "description":"an alphanumeric pattern used to find geographic locations.",
                    "type":"string",
                    "pattern":"^[a-zA-z0-9 ]+$"
                },
                "limit": {
                    "description":"the maximum number of matching places that may be returned.",
                    "type":"integer",
                    "minimum":0
                },
                "found": {
                    "description":"the total number of matching places in the data source(s).",
                    "type":"integer",
                    "minimum":0
                },
                "narrow": {
                    "description":"additional field",
                    "type":"array",
                    "items":{
                        "type":"object",
                        "properties":{
                            "type":{"type":"string"},
                            "country":{"type":"string"}
                        },
                        "required": [],
                        "additionalProperties": true
                    },
                    "minitems": 0
                },
                "places": {
                    "description": "list of places places found",
                    "type":"array",
                    "items": {
                        "type":"object",
                        "properties": {
                            "name": {"type":"string"},
                            "latitude": {"type":"string",
                                "pattern":"^[-+]?(?:90(?:(?:\\.0+)?)|(?:[0-9]|[1-8][0-9])(?:(?:\\.[0-9]+)?))$"},
                            "longitude": {"type":"string",
                                "pattern":"^[-+]?(?:180(?:(?:\\.0+)?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\\.[0-9]+)?))$"},
                            "id": {"type":"string"},
                            "municipality": {"type":"string"},
                            "altitude": {"type":"string", "pattern":"^[0-9]+(\\.[0-9]+)?$"}
                        },
                        "required": ["latitude","longitude"],
                        "additionalProperties": true
                    },
                    "minitems": 0
                }
            },
            "required":["requestVersion","requestType","match"],
            "additionalProperties": false
        };

        let ajv = new Ajv({allErrors:true});
        const validator = ajv.compile(schema);
        let v = validator(value);
        return v;
    }


}