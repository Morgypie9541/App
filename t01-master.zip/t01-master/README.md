# T01-Team Doggo
![Team_Picture](/team/images/team-doggos.png "A Picture of our Dogs")  
Title=*A Cute Picture of our Doggos*

| Name | eID | GitHub Username | Email |
|------|-----|-----------------|-------|
| Kaleb Welsh | kwelsh | ScrappyKingK | kwelsh@rams.colostate.edu |
| Alyssa Watts | arwatts | arwatts16 | arwatts@rams.colostate.edu |
| Miriam Alzamily | alzamily | malzamily | miriamalzamily@gmail.com |
| Will McDonald | willomcd| willyomcd | willyomcd@gmail.com |
| Morgan Roe| maroe | Morgs-R| maroe@rams.colostate.edu |