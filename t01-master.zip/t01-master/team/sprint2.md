# Sprint 2 - T01 - Team Doggos

## Goal
### A map and itinerary!
* Allow Users to submit an itinerary to see a map and details about a trip they wish to take.
* Allow users more options of units to use when using the distance calculator.
* Follow the practices of Test-Driven development, and learn more about Junit testing.
* Understand and implement cookies with ReactJS.

### Sprint Leader: *Kaleb Welsh*

## Definition of Done

* Version in pom.xml should be `<version>2.0.0</version>` for your final build for deployment.
* Increment release `v2.0` created on GitHub with appropriate version number and name.
* Increment deployed for testing and demonstration on SPRINT2 assignment.
* Sprint Review and Restrospectives completed (team/sprint2.md).


## Policies

#### Mobile First Design!
* Design for mobile, tablet, laptop, desktop (in that order).
* Use ReactStrap for a consistent interface (no HTML, CSS, style, etc.).
* Must adhere to the TripCo Interchange Protocol (TIP) for interoperability and testing.
#### Clean Code
* Code Climate maintainability of A or B.
* Code adheres to Google style guides for Java and JavaScript.
#### Test Driven Development
* Write method headers, unit tests, and code in that order.
* Unit tests are fully automated.
#### Configuration Management
* Always check for new changes in master to resolve merge conflicts locally before committing them.
* All changes are built and tested before they are committed.
* All commits include a task/issue number.
* All commits include tests for the added or modified code.
* All tests pass.
#### Continuous Integration / Delivery 
* Master is never broken.  If broken, it is fixed immediately.
* Continuous integration successfully builds and tests all pull requests for master branch.
* All Java dependencies in pom.xml.  Do not load external libraries in your repo. 


## Plan

This sprint will complete the following Epics.

* *#17 User: I want to compute the distance between two locations on the planet:* We will complete this Epic from last sprint by            reporting invalid data to user on the client side.
* *#18 User: I may need distances in other units of measure:* Save them so the user doesn't need to reenter them again in the future.
* *#65 User: Show me a map and itinerary for my trip:* 
  * My itinerary is in a file created by a tool.
  * I should be able to load the itinerary from a file.
  * I'd like to see the leg and cumulative distances at each stage in the itinerary.
  * I'd like to see an interactive map showing my entire trip on the screen.
  * I'd like to be able to choose what to display for each destination in the itinerary.
  * I'd like to save the itinerary with the leg distances to a file for future reference or use in another tool.  The new file should       maintain the original values for the latitude and longitude.
 * *#66 User: Enter latitudes and longitudes in the calculator using degree-minute-second and other formats:* * There are many formats       for latitudes and longitudes that I encounter online while finding possible destinations for my trips.  I should be able to enter       them.
 * *#67 User: The calculator data shouldn't go away when units change: * When I change units I shouldn't lose the latitude and longitude      information, and the distance should also get updated when I change the units.


## Metrics

| Statistic | # Planned | # Completed |
| --- | ---: | ---: |
| Epics | *5* | *3* |
| Tasks |  *12*   | *9* | 
| Story Points |  *17*  | *13* | 


## Scrums

| Date | Tasks closed  | Tasks in progress | Impediments |
| :--- | :--- | :--- | :--- |
| *2/13* | *None* | *Added Bug #81* | *None* | 
| *2/15* | *#84* | *#33,#72* | *Issue #74 blocked by #72* |
| *2/18* | *#75* | *#33,#72* | *Issue #74 blocked by #72* |
| *2/20* | *#33* | *#72* | *Issue #74 & #73 blocked by #72* |
| *2/22* | *#72, #73* | *#74* | *None* |
| *2/25* | *#102,#104,#105* | *#74,#69* | *None* |
| *2/27* | *#69,#68,#70* | *#74* | *None* |

## Review (focus on solution and technology)

In this sprint, we aimed to have a better understanding of react-leaflet, Jest testing, and how clients communicate with servers.

#### Completed epics in Sprint Backlog 

These Epics were completed.

* *#17 User: I want to compute the distance between two locations on the planet:* We will complete this Epic from last sprint by            reporting invalid data to user on the client side.
 * *#66 User: Enter latitudes and longitudes in the calculator using degree-minute-second and other formats:* * There are many formats       for latitudes and longitudes that I encounter online while finding possible destinations for my trips.  I should be able to enter       them.
* *#65 User: Show me a map and itinerary for my trip:* 
  * My itinerary is in a file created by a tool.
  * I should be able to load the itinerary from a file.
  * I'd like to see the leg and cumulative distances at each stage in the itinerary.
  * I'd like to see an interactive map showing my entire trip on the screen.
  * I'd like to be able to choose what to display for each destination in the itinerary.
  * I'd like to save the itinerary with the leg distances to a file for future reference or use in another tool.  The new file should       maintain the original values for the latitude and longitude.
  
#### Incomplete epics in Sprint Backlog 

These Epics were not completed.

* *#18 User: I may need distances in other units of measure:* Save them so the user doesn't need to reenter them again in the future.
 * *#67 User: The calculator data shouldn't go away when units change: * When I change units I shouldn't lose the latitude and longitude      information, and the distance should also get updated when I change the units.


#### What went well

The technology we used this sprint worked relatively well. The majority of us were able to understand how tests functioned on both 
client and server side. We also had success with utilizing libraries, i.e. coordinate-parser, to more efficently complete work in our sprint.

#### Problems encountered and resolutions

A lot of our work was blocked from waiting for people to finish certain tasks in an Epic. We had to make an
collective decision to move on to other Epics so all our work wasn't halted by one task.


## Retrospective (focus on people, process, tools)

In this sprint, we aimed to move to a functional state in our group. Also, we aimed to follow test driven development more closely. 
Along with this, we worked on polishing skills from our first sprint, such as skills with github.

#### What we changed this sprint

Our changes for this sprint included making sure to test important parts of our code. We also started to define roles for some people in 
our group, and what they should focus on.

#### What we did well

We were better about testing edge cases on our server side. We also took the users experience into consideration
when deciding on how to format our client side.

#### What we need to work on

We could improve how we deal with tasks and epics. There were some tasks that were too big we didn't break up into smaller tasks or even smaller epics. 

#### What we will change next sprint 

We will change how we deal with larger tasks and epics that we find to be more difficult than we initially believed. In the next sprint we'll be better about breaking down bigger tasks even once the sprint has started or once we've already started the task. 
