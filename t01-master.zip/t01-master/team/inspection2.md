# Inspection - Team *T01* 

| Inspection | Details |
| ----- | ----- |
| Subject | *Itinerary.js* |
| Meeting | *4/15/19, 3:00, in Class* |
| Checklist | *reference, URL, etc.* |

### Roles

| Name | Preparation Time |
| ----- | ----- |
| Kaleb | 20 mins |
| Morgan | 30 minutes |
|Will| 20 minutes |
| Alyssa | 30 minutes |
|  |  |

### Problems found

| file:line | problem | hi/med/low | who found |
| --- | --- | :---: | :---: |
|Itinerary.js Line 39 | Itinerary state hasn't been lifted, only mounted. So it's data cannot be used by other components.| low |Kaleb|
|Itinerary.js Line 67 | SQL queries do not update the map when a place is added from them.| med |Kaleb|
|Itinerary.js Line 128 | InnerHTML element doesnt exist yet if this function is called with state lifted.| low |Kaleb|
|Itinerary.js Line 217 | Map doesn't update bounds with worldwide dataset; hard coded to colorado.| med |Kaleb|
|Itinerary.js Line 312 | This line will only accept JSON files and nothing else.| high |Kaleb|
|Itinerary.js Line 331 | Needlesly creating a higher level var when not nssecary (var i=0)| low |Kaleb|
|Itinerary.js Line 36 | this.selectedOptimizationLevel is an unused variable| low |Morgan|
|Itinerary.js Line 84 | OPT-2 button needs to go, not implemented yet| low |Morgan|
|Itinerary.js Line 36 | Redesign of button layout to either remove 'None' Or be able to revert the trip back to that state| low |Morgan|
|Itinerary.js Line 83 | Map re-rendering still needs to be added when short optimization is chosen| hi |Morgan|
|Itinerary.js Line 308| Redundant code between updateFileOnChange and updateMarkersandLines| med| Will|
|Itinerary.js Line 205| We probably shouldn't use both state and props to hold places/markers/lines| med| Will|
|Itinerary.js| Distances aren't converted to degrees if inputed in a different coordinate format| hi| Alyssa|
|Itinerary.js| Markers aren't always correct, so we need to take them off the map to avoid confusion | med| Alyssa|



### Problems to be fixed
| file:line | problem | hi/med/low | who found | github#  |
| --- | --- | :---: | :---: | --- |
|  
