# Sprint 5 - *t01* - *Team Doggos*

## Goal

### A Beautiful User Experience!
### Sprint Leader: *Alyssa Watts*

## Definition of Done

* Version in pom.xml should be `<version>5.0.0</version>` for your final build for deployment.
* Increment release `v5.0` created on GitHub with appropriate version number and name.
* Increment `server-5.0.jar` deployed for testing and demonstration on SPRINT5 assignment.
* Sprint Review, Restrospective, and Metrics completed (team/sprint5.md).


## Policies

#### Mobile First Design!
* Design for mobile, tablet, laptop, desktop (in that order).
* Use ReactStrap for a consistent interface (no HTML, CSS, style, etc.).
* Must adhere to the TripCo Interchange Protocol (TIP) for interoperability and testing.
#### Clean Code
* Code Climate maintainability of A or B.
* Code adheres to Google style guides for Java and JavaScript.
#### Test Driven Development
* Write method headers, unit tests, and code in that order.
* Unit tests are fully automated.
* Code Coverage above 50%
#### Configuration Management
* Always check for new changes in master to resolve merge conflicts locally before committing them.
* All changes are built and tested before they are committed.
* All commits include a task/issue number.
* All commits include tests for the added or modified code.
* All tests pass.
#### Continuous Integration / Delivery 
* Master is never broken.  If broken, it is fixed immediately.
* Continuous integration successfully builds and tests all pull requests for master branch.
* All Java dependencies in pom.xml.  Do not load external libraries in your repo. 
* Each team member must complete Interop with another team and file an issue in the **class** repo with the results.
  * title is your team number and your name, 
  * labels should include Interop and the Team that you tested with, 
  * description should include a list of tests performed, noting any failures that occurred.


## Plan

This sprint will complete the following Epics.

* *#170 User: I want to view my trip in other tools*
* *#221 User: Make the application easier to use*
* *#19 User: I want to know where I am on the map*
* *#226 User: I would like schema validation*

***Our plan for this sprint is focused mostly on epic #221, and improving anything that may have been left unfinished or polished from previous sprints. Since we are no longer forming as a new team and have been working together for a few weeks now, everyone feels more comfortable in the code base and contributed different ideas that our user experience was lacking. We also, however, wanted to be able to implement other small epics like #226 and #19 to improve the overall product, and we wanted to finosh #170 from last time.***


## Metrics

| Statistic | # Planned | # Completed |
| --- | ---: | ---: |
| Epics | *4* | *4* |
| Tasks |  *19*   | *19* | 
| Story Points |  *22*  | *20* | 


## Scrums

| Date | Tasks closed  | Tasks in progress | Impediments |
| :--- | :--- | :--- | :--- |
| *4/24* |  | *#236, #231* | *none* | 
| *4/26* | *#231* | *#223, #224, #225, #237* | *none* | 
| *4/29* | *#223, #224, #225, #236* | *#181* | *none* | 
| *5/1* | *#181* | *#182* | *none* | 
| *5/3* | *#182, #237* | *#232, #234, #238, #233, #252* | *none* | 
| *5/6* | *#232, #234, #238, #233, #252* | *#183, #227, #228, #229, #230, #235* | *none* | 
| *5/8* | *#183, #227, #228, #229, #230, #235* |  | *none* | 


## Review (focus on solution and technology)

In this sprint, we focused on fixing any bugs that we found within our code in order to make it ready for launch. We also focused on other file types for saving itinerary, other small convinences to improve itinerary (such as a 'clear itinerary' button), and implementing schemas for json validation.  

#### Completed epics in Sprint Backlog 

These Epics were completed.

* *#19 User: I want to know where I am on the map: We had this sitting in our ice box since the first sprint and thought it appropriate to finally implement it for the final product*
* *#170 User: I want to view my trip in other tools: Being able to output our files into a csv or kml file was a very big feature we though important to add for functionality*
* *#221 User: Make the application easier to use: This was the big epic we focused on, with fixing any bugs that we saw and trying to adapt everything to be more put together and concise especially for mobile*
* *#226 User: I would like schema validation: We had been having interop issues in the previous sprint and this validation became a big way for us to look at all of our code and make sure it was up to the schema and TIP standards for the class*

#### Incomplete epics in Sprint Backlog 

These Epics were not completed.

* *None*

#### What went well

When we started looking into our schema validation, we were able to fix a lot of interop issues that we had been having. We also, in this sprint, implemented a lot of reactstrap elements, like tabs, that enhanced the user experience of our application and made it appear more succinct. 


#### Problems encountered and resolutions

We were having issues with small design measures, where fixing certain bugs in the itinerary would cause another bug to pop up in another place. We also struggled with all working on relatively similar functions and files at the same time and small bugs in one programming causing others in the group to have to troubleshoot more. Our solution for this was to have open communication with each other and have a few set of eyes on new changes to code to prevent these issues from happening. 


## Retrospective (focus on people, process, tools)

In this sprint, we definitely did a better job of delegating tasks to everyone and working more as a team than in previous sprints. This is evident in the fact that we got all of our tasks, but one, done. 

#### What we changed this sprint

Our changes for this sprint included making sure that we're being realistic about the number of tasks and epics that we are tackling and not trying to implement too many new things at once that could cause bugs or that could cause us to get behind on our burndown chart by having more to do than is possible. 

#### What we did well

We communicated better as a team this sprint and it definitely helped us work better together. We also had a lot of instances where one person would need help figuring out a small issue in some section of code and there was always someone else in the group that would be there to help. 

#### What we need to work on

We could improve on checking each others merge requests before adding them to the master. There were a few small issues that could've been avoided just by really looking at and analyzing what the merge request held. 

#### What we will change next sprint 

We will change the way that we merge things into master, and make sure that we are taking a critical look at what the changes are and what possible implications of various things could be. 
