# Teamwork Questionnaire for Miriam Alzamily

1. __Is it generally easier to reach you by text, electronic mail, voice mail or something else?  What hours?__ 
   * Texting or emailing would be the fastest way to reach me. 8am - 11pm
1. __What are your expectations about what your team will accomplish this semester?__ 
   * We'll successfully complete each sprint. I think it would also be beneficial to try and get everything done at least a day before the due date, to avoid any last minute stress.
1. __What are your personal goals for improving your teamwork and communication skills this semester?__ 
   * I plan on completing my work on time and making sure that I am contributing just as much as everyone else. I'll also listen to what my teammates have to say, whether that be suggestions, concerns, etc.
1. __What kinds of obstacles might you encounter in trying to reach both your team and personal goals?__ 
   * I think the biggest challenge will be if I get stuck and am unsure on how to complete my portion of the work. 
1. __What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?__ 
   * As long as everyone is completing the work that they agreed to do, then hopefully we can all be at a level that is acceptable to everyone.
1. __Is it acceptable for some team members to do more work on the assignment in order to get an “A”?__ 
   * Sure, as long as it isn't taking away from others who agreed that they can/will do it.
1. __How much time per week do you anticipate it will take to make the project successful?__ 
   * I agree with what was said in class. Working incrementally and making contributions at least every few days seems like the best approach.
1. __How will you decide who should do what on the project and activities?__ 
   * We can talk as a group and make a decision that works for everyone
1. __What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?__ 
   * If the person knows that they won't be able to follow through, they should let the group know ahead of time. 
1. __What happens if people have different opinions on the quality of the work?__ 
   * I don't think anyone should be held back if they want to improve something. 
1. __How will you deal with different work habits of team members?__ 
   * As long as everyone is getting their work done on time, differing work habits shouldn't be an issue. 
1. __Do you want to have a standing meeting time outside of class?__ 
   * I think it would be helpful to have one.
1. __How often do you think the team will need to meet outside of class?__ 
   * Whatever we think is necessary. It may be more frequent if not enough progress is being made.
1. __Will you need approval of every team member before making a decision?__ 
   * Only if the decision could interfere with others
1. __What will you do if every team member except one agrees on something?__ 
   * Have a discussion and come to some kind of agreement
1. __What will you do if one person seems to be dominating the team process?__ 
   * If that person or others have a problem with it, we can talk as a group and find another way to split the work.
1. __What will you do if you feel most of the facilitation responsibilities are falling on you?__ 
   * I'd let my team know
