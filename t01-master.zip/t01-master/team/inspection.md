# Inspection - Team *T01* 

| Inspection | Details |
| ----- | ----- |
| Subject | *Optimizations.java and TIPItinerary.java* |
| Meeting | *4/8/19, 3:00, in Class* |
| Checklist | *reference, URL, etc.* |

### Roles

| Name | Preparation Time |
| ----- | ----- |
| Morgan | 30 minutes |
| Alyssa | 30 minutes |
|  |  |

### Problems found

| file:line | problem | hi/med/low | who found |
| --- | --- | :---: | :---: |
| Optimizations.java - line 150 - 158 | Using slightly different data structures for our optimization function require a transformation  | lo | Morgan |
| Optimizations.java - All | minimal use of comments is going to make further optimization difficult as somebody else will most likely be writing the code  | med | Morgan |
| TIPItinerary.java - line 36 and 39 | Using slightly different data structures for our optimization function require a transformation  | lo | Morgan |
| TIPItinerary.java - line 59 and 60 | Using slightly different data structures for our optimization function require a transformation  | lo | Morgan |
| TIPItinerary.java - line 42 and 73 | we call for greatCircleDistance twice but I don't think we need to keep recalculatng distances | med | Alyssa |
| TIPItinerary.java - buildResponse | clean up for code climate - split method into two functions, whether or not there is optimization | lo | Alyssa |
| Optimizations.java - line 116| we don't supply with a new first destination, at least not yet, so I don't think this part is needed? | lo | Alyssa |

### Problems to be fixed
| file:line | problem | hi/med/low | who found | github#  |
| --- | --- | :---: | :---: | --- |
| TIPItinerary.java - line 42 and 73 | we call for greatCircleDistance twice but I don't think we need to keep recalculatng distances | med | Alyssa |  |
| TIPItinerary.java - buildResponse | clean up for code climate - split method into two functions, whether or not there is optimization | lo | Alyssa |  |
|  | | | | |
