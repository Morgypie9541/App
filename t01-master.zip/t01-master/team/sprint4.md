# Sprint 4 - *T01* - *Team  Doggos*

## Goal

### Worldwide!
### Sprint Leader: *Will McDonald*

## Definition of Done

* Version in pom.xml should be `<version>4.0.0</version>` for your final build for deployment.
* Increment release `v4.0` created on GitHub with appropriate version number and name.
* Increment `server-3.5.jar` deployed for testing and demonstration on CHECK4 assignment.
* Increment `server-4.0.jar` deployed for testing and demonstration on SPRINT4 assignment.
* Sprint Review, Restrospective, and Metrics completed (team/sprint4.md).


## Policies

#### Mobile First Design!
* Design for mobile, tablet, laptop, desktop (in that order).
* Use ReactStrap for a consistent interface (no HTML, CSS, style, etc.).
* Must adhere to the TripCo Interchange Protocol (TIP) for interoperability and testing.
#### Clean Code
* Code Climate maintainability of A or B.
* Code adheres to Google style guides for Java and JavaScript.
#### Test Driven Development
* Write method headers, unit tests, and code in that order.
* Unit tests are fully automated.
* Code Coverage above 50%
#### Configuration Management
* Always check for new changes in master to resolve merge conflicts locally before committing them.
* All changes are built and tested before they are committed.
* All commits include a task/issue number.
* All commits include tests for the added or modified code.
* All tests pass.
#### Continuous Integration / Delivery 
* Master is never broken.  If broken, it is fixed immediately.
* Continuous integration successfully builds and tests all pull requests for master branch.
* All Java dependencies in pom.xml.  Do not load external libraries in your repo. 


## Plan

This sprint will complete the following Epics.

* *#128 User: Make my trip shorter*
* *#127 User: Let me change my itinerary*
* *#168 User: Let me plan trips worldwide*
* *#169 User: I would like to highlight certain places on the map*
* *#170 User: I want to view my trip in other tools*


  This is the first week with a newly re-constructed group. We planned our epics around two people 
becoming familiar with code base and implementing features their prior group had already implemented. 
This sprint is focused around improving our itinerary***


## Metrics

| Statistic | # Planned | # Completed |
| --- | ---: | ---: |
| Epics | 5 | 4 |
| Tasks |  18   | 16 | 
| Story Points |  20 | 17 | 


## Scrums

| Date | Tasks closed  | Tasks in progress | Impediments |
| :--- | :--- | :--- | :--- |
| 4/3 |  | #184, #161, #172 | none |
| 4/5 | #184, #161 | #189, #173| none |
| 4/8 | #172 | #193, #176, #173| none |
| 4/10 | #193, #176 |#173| snow day: made scrum harder |
| 4/12 | #189 | #180, #179, #178, #177, #173 | none |
| 4/15 | #180, #179, #178, #177 | #173 | none |
| 4/17 | #173 | #175, #174| :--- |




## Review (focus on solution and technology)

In this sprint, we integrated new team members and worked on catching up on the big epics from sprint 3

#### Completed epics in Sprint Backlog 

These Epics were completed.

* *#128 User: Make my trip shorter*
* *#127 User: Let me change my itinerary*
* *#168 User: Let me plan trips worldwide*
* *#169 User: I would like to highlight certain places on the map*

#### Incomplete epics in Sprint Backlog 

These Epics were not completed.

* *#170 User: I want to view my trip in other tools*

#### What went well

We were able to leverage some of the late T22's code to help with the "Make my trip shorter" epic. Teammates used their
knowledge and skills from other classes to help with the "let me plan trips worldwide" epic. 


#### Problems encountered and resolutions

No big problems. We collectively did not start on "viewing trips in other tools." We resolved to not start it too last minute 
and work on it next time.


## Retrospective (focus on people, process, tools)

Disclaimer: This is my first sprint within team 01 so its hard to make assesments of where we are compared to prior sprints

We did a good job planning which kept us fairly organized for the whole sprint. Our process was good, however our team was very busy 
week 2 so we did most of the work in the 1st and 3rd week of the sprint. We still almost achieved our initial goals

#### What we changed this sprint

Our changes for this sprint included adding two new members of the team. It took a little time for them to understand a whole new code base, but overall the merger was successful. The new inspections helped us collaberate on fixing some of the issues within our itinerary and optimization code.

#### What we did well

We communicated well as a team, collaberating on issues within our itinerary alot. I want to emphasize how much planning
can affect the whole sprint. It was a weak-point of my prior team and we were much less organized because of it.

#### What we need to work on

I think a lot is in place to have a successful sprint 5. Some of our scrum discussions could have been more thorough. We didn't always bring up issues in class when it would have been easiest to talk through them. I think we could try to utilize in class scrums more.

#### What we will change next sprint 

We will try to not bite off more than we can chew. In our final sprint, I think we will be trying to improve what we have
instead of soley focusing on new features. We will focus more on testing and fixing bugs within our current product.
