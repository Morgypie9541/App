# Sprint 3 - T01 - Team Doggos

## Goal

### Shorter trips to more places!
### Sprint Leader: *Miriam Alzamily*

## Definition of Done

* Version in pom.xml should be `<version>3.0.0</version>` for your final build for deployment.
* Increment release `v3.0` created on GitHub with appropriate version number and name.
* Increment `server-3.0.jar` deployed for testing and demonstration on SPRINT3 assignment.
* Sprint Review, Restrospective, and Metrics completed (team/sprint3.md).


## Policies

#### Mobile First Design!
* Design for mobile, tablet, laptop, desktop (in that order).
* Use ReactStrap for a consistent interface (no HTML, CSS, style, etc.).
* Must adhere to the TripCo Interchange Protocol (TIP) for interoperability and testing.
#### Clean Code
* Code Climate maintainability of A or B.
* Code adheres to Google style guides for Java and JavaScript.
#### Test Driven Development
* Write method headers, unit tests, and code in that order.
* Unit tests are fully automated.
* Code Coverage above 40%
#### Configuration Management
* Always check for new changes in master to resolve merge conflicts locally before committing them.
* All changes are built and tested before they are committed.
* All commits include a task/issue number.
* All commits include tests for the added or modified code.
* All tests pass.
#### Continuous Integration / Delivery 
* Master is never broken.  If broken, it is fixed immediately.
* Continuous integration successfully builds and tests all pull requests for master branch.
* All Java dependencies in pom.xml.  Do not load external libraries in your repo. 


## Plan

This sprint will complete the following Epics.

* *#67 User: The calculator data shouldn't go away when units change:* When I change units I shouldn't lose the latitude and longitude information, and the distance should also get updated when I change the units.
* *#18 User: I may need distances in other units of measure:* Save them so the user doesn't need to reenter them again in the future.
* *#126 User: Data shouldn't go away when I change tabs:* Preserve data when changing tabs.
* *#127 User: Let me change my itinerary:* Be able to add new locations to itinerary, remove existing ones, rearrange, and choose a new starting location.
* *#128 User: Make my trip shorter:* Use the nearest neighbor algorithm to shorten the trip and allow an optional optimization. 

Discussion of plan:
We decided how many epics to add based on how much work we completed last sprint, while also taking into consideration the improvements we hope to make. To reach the goal of this sprint, we chose to add three new epics. We then went about breaking these epics up into tasks and assigning them story points. If a task was worth more than 3 story points, it was split up into more tasks, so each would be worth only 1-3 story points. 


## Metrics

| Statistic | # Planned | # Completed |
| --- | ---: | ---: |
| Epics | *5* | *3* |
| Tasks |  *13*   | *8* | 
| Story Points |  *17*  | *11* | 


## Scrums

| Date | Tasks closed  | Tasks in progress | Impediments |
| :--- | :--- | :--- | :--- |
| *3/6* | *N/A* | *N/A* | *none* | 
| *3/8* | *N/A* | *#76* | *none* | 
| *3/11* | *#76, #77, #131* | ** | *none* | 
| *3/15* | *#145, #80* | ** | *Team Mate Dropped* | 

## Review (focus on solution and technology)

In this sprint, it was important for us to focus on improving test coverage, understanding schemas, and using data sources, such as an SQL database. 

#### Completed epics in Sprint Backlog 

These Epics were completed.

* *#67 User: The calculator data shouldn't go away when units change:* When I change units I shouldn't lose the latitude and longitude information, and the distance should also get updated when I change the units.
* *#18 User: I may need distances in other units of measure:* Save them so the user doesn't need to reenter them again in the future.
* *#126 User: Data shouldn't go away when I change tabs:* Preserve data when changing tabs.

#### Incomplete epics in Sprint Backlog 

These Epics were not completed.

* *#127 User: Let me change my itinerary:* Be able to add new locations to itinerary, remove existing ones, rearrange, and choose a new starting location.
* *#128 User: Make my trip shorter:* Use the nearest neighbor algorithm to shorten the trip and allow an optional optimization. 

#### What went well

We were able to utilize the resources made available to us, along with have discussions to help with problem solving. 

#### Problems encountered and resolutions

Interop testing helped reveal some issues in our code, and based on these observations and comments from others, most issues were able to be resolved. 

## Retrospective (focus on people, process, tools)

In this sprint, our goal was to make the improvements and changes that we reflected on at the end of the last sprint. We also focused on what was being emphasized in class, such as testing.  

#### What we changed this sprint

Our changes for this sprint included how and when we made decisions when it came to deadlines and replanning. We were also introduced to Code Climate maintainability.

#### What we did well

We were better at finding and fixing bugs that were noticed throughout the sprint. 

#### What we need to work on

We need to continue to improve how we plan the sprint, since we lost some points for the SP3 Plan. It would be beneficial to split epics up so that the tasks are as small and as simple as they can be. We also need to adjust to having a smaller team.  

#### What we will change next sprint 

We will change how we go about planning, as stated above. Also, for the next sprint, and as the semester progresses, focusing on time management is important so that the work is evenly distributed, and so that more can get completed.
