# Sprint 1 - *t01* - *Team Doggos*

## Goal

### Distance Calculator!
### Sprint Leader: *Alyssa Watts*

## Definition of Done

* Web application deployed on the production server (black-bottle.cs.colostate.edu).
* Version in server/pom.xml should be `<version>1.0</version>`.
* Product Increment release `v1.0` created on GitHub.
* Sprint Review and Restrospectives completed (sprints/sprint#.md).

## Policies

* All commits include a task/issue number.
* Someone else approves and merges commits, you may not merge your own changes.
* No commits to master

## Plan

Epics planned for this release.

* *#1 TripCo: The application should identify the client and server currently in use.*
* *#2 TripCo: Use a standard logging system on the server*
* *#3 User: I'd like to know who to thank for this tool*
* *#4 User: I want to compute the distance between two locations on the planet.*
* *#5 User: I want to know where I am on the map*
* *#6 User: I may need distances in other units of measure*


## Review

#### Completed epics in Sprint Backlog 
* *#1 TripCo: The application should identify the client and server currently in use.*: (3 tasks) comments: The server configuration was modified so that the clients can identify which server they are using in the navigation bar with the title displaying in the browser tab, “T01 Team Doggos”.
* *#2 TripCo: Use a standard logging system on the server*: (4 tasks) comments: We created toString methods for each class that output various info from each class.
* *#3 User: I'd like to know who to thank for this tool*: (5 tasks) comments: Created About Page and added information on each team member

#### Incomplete epics in Sprint Backlog 
* *#4 User: I want to compute the distance between two locations on the planet.*: (3 tasks) explanation: We completed most the issues besides throwing a client side error when they input incorrect data.
* *#5 User: I want to know where I am on the map*: Because we did not finish epic #4, we were not able to start this one. 
* *#6 User: I may need distances in other units of measure*: Because we did not finish epic #4, we were not able to start this one.

#### What went well
* We were able to finish the epics relatively easily. 


#### Problems encountered and resolutions
* Oftentimes people were confused on what tasks they were responsible for, so we need to be better at planning that. 


## Retrospective

#### What went well
* We were able to split up the tasks pretty evenly. 
* Nobody dominated an epic, everybody took part in at least 2 of the 3 epics we completed for this sprint. 

#### Potential improvements
* For the code: error checking for latitude and longitude user inputs

#### What we will change next time
* We need to establish a more efficient schedule for when each task needs to be done. 
* We need to be better about assigning epics beforehand and establishing who's doing what earlier in the planning process. 
