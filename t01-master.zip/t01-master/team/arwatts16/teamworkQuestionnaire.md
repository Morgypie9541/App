# Teamwork Questionnaire for Alyssa Watts

1. __Is it generally easier to reach you by text, electronic mail, voice mail or something else?  What hours?__ 
   * The easiest way to reach me is by text or email, from around 7am to 12am(Midnight) on weekdays. On weekends I'm usually up by 10am. 
1. __What are your expectations about what your team will accomplish this semester?__ 
   * I want to be able to make something with as many features as we can accomplish while maintaining a code base that is sturdy and won't break easily. 
1. __What are your personal goals for improving your teamwork and communication skills this semester?__ 
   * I want to make sure that we divide up work evenly as a team and I personally am going to try and be more willing to seek help when I've been stuck for awhile. 
1. __What kinds of obstacles might you encounter in trying to reach both your team and personal goals?__ 
   * It might be hard to reach out for help on issues that I'm having if everyone else is busy working on their parts. Also, splitting up work evenly is sometimes hard because some issues are more difficult than others so it will be something we have to discuss and agree on. 
1. __What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?__ 
   * My personal goal in this class is to get an A, and I'm going to try and push our project to be at that level.
1. __Is it acceptable for some team members to do more work on the assignment in order to get an “A”?__ 
   * Yes. 
1. __How much time per week do you anticipate it will take to make the project successful?__ 
   * Maybe an hour at least every other day, and a few hours total on the weekends?
1. __How will you decide who should do what on the project and activities?__ 
   * We can see what everyone feels most comfortable with and if anyone wants to try and do a particular part and go from there.  
1. __What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?__ 
   * As a group we should all make sure that we're all aware of due dates and checking in on each other when that person is turning in an assignment. It would also be good to let the group know when you've finished and turned something in so that everyone is on the same page. 
1. __What happens if people have different opinions on the quality of the work?__ 
   * We can discuss as a group if the person asking for more quality should work on it independently, or maybe everyone could meet up and as a group we can improve the quality quickly together for an hour or something like that.
1. __How will you deal with different work habits of team members?__ 
   * Understand that as long as the work is getting done in a timely manner, and not prohibiting other from doing their work that it's fine for us to have different habits. 
1. __Do you want to have a standing meeting time outside of class?__ 
   * I think it would be a good idea to have weekly meetings outside of class. 
1. __How often do you think the team will need to meet outside of class?__ 
   * Once a week, maybe twice on demo weeks?
1. __Will you need approval of every team member before making a decision?__ 
   * If it's a big decision I'll seek out the approval of everything, if it's something small or a minor detail I'll probably only seek one opinion. 
1. __What will you do if every team member except one agrees on something?__ 
   * Find out why that person says no and come to a compromise or convince them the other way is better.
1. __What will you do if one person seems to be dominating the team process?__ 
   * Let them know that they need to back off a little bit and that we all need to be doing equal shares of the work. 
1. __What will you do if you feel most of the facilitation responsibilities are falling on you?__ 
   * Talk to my team members and make suggestions of responsibilites I would like others to take care of. 
