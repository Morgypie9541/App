# Teamwork Questionnaire for Kaleb Welsh

1. __Is it generally easier to reach you by text, electronic mail, voice mail or something else?  What hours?__ 
   * It is easiest to reach me by text during the hours 9AM-10PM.
1. __What are your expectations about what your team will accomplish this semester?__ 
   * We will have good communication while making great progress on our SCRUM team's stories and Epics.
1. __What are your personal goals for improving your teamwork and communication skills this semester?__ 
   * To offer my help whenever applicable to make sure that the entire team understands what is going on.
1. __What kinds of obstacles might you encounter in trying to reach both your team and personal goals?__ 
   * I often expect people to figure out their problems on their own, so this is definitly something I will need to work on. Also, we could encounter personality type issues.
1. __What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?__ 
   * I personally don't care, as long as we put our best foot forward, and complete the projects in a timely manner I will be happy.
1. __Is it acceptable for some team members to do more work on the assignment in order to get an “A”?__ 
   * Yes, if they want to put in the extra effort to do so, then they deserve an A.
1. __How much time per week do you anticipate it will take to make the project successful?__ 
   * An hour everyday, with some extra work on the weekends should be more then eenough to make our project a success.
1. __How will you decide who should do what on the project and activities?__ 
   * We will look at the strengths/weaknesses of each teammate, and assign suitable rolls from there.
1. __What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?__ 
   * We will try to encourage that person to finish their work, but at the end of the day we can't force them to do something and will inform "managers" of their work ethic.
1. __What happens if people have different opinions on the quality of the work?__ 
   * Hopefully we will be able to find a common ground, or at least help each other to understand the others opinion.
1. __How will you deal with different work habits of team members?__ 
   * If they complete their parts by the end of the sprint, I will have no issue with how they do so.
1. __Do you want to have a standing meeting time outside of class?__ 
   * Yes, I think that would be a great idea. We can discuss this at our "daily stand up".
1. __How often do you think the team will need to meet outside of class?__ 
   * I think 1 to 2 times a week will put us on track to understanding what we need to accomplish that sprint.
1. __Will you need approval of every team member before making a decision?__ 
   * If it interacts with other teamates work, yes, because we dont want to step on each others toes.
1. __What will you do if every team member except one agrees on something?__ 
   * Majority rules. People have differnece in opinions always, there is no way to combat that.
1. __What will you do if one person seems to be dominating the team process?__ 
   * Try to reliviate some of there stress by telling them to trust in our ability to accomplish work.
1. __What will you do if you feel most of the facilitation responsibilities are falling on you?__ 
   * I will converse with our "managers" since this is a team effort and a big project to undertake on one own.
