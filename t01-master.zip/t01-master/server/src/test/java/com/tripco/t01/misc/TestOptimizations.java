package com.tripco.t01.misc;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.*;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestOptimizations {
    private Optimizations opt;
    List<Map<String,String>> places;
    String firstPlace = "";
    double radius = 3958.761316;
    List<Integer> distances;
    List<Map<String, String>> places2;
    Map<String, String> m1;

    @Before
    public void createOptTestCase(){
        opt = new Optimizations();
        places = new ArrayList<>();
        distances= new ArrayList<Integer>();
        places2 = new ArrayList<>();
        m1 = new HashMap<String,String>();
        m1.put("name","Wolf Creek");
        m1.put("id","1");
        m1.put("latitude","37.28333");
        m1.put("longitude","-106.475833");
        places2.add(m1);
    }

    @Test
    public void  testMakeTripShorter(){
        List<Map<String,String>> temp = new ArrayList<>();
        List<Integer> i = new ArrayList<>();
        i.add(0);
        temp = opt.MakeTripShorter(places2,firstPlace,radius,i);
        assertEquals(temp,places2);

    }
    @Test
    public void testnNAlgo(){
        int[][] adjList = new int[1][1];
        adjList[0][0] = 0;
        int fPlace= 0;
        int[] disty= {1};
        int[] rez = opt.nNAlgo(adjList,fPlace,disty);
        assertEquals(rez[0],0);
    }
    @Test
    public void testfindFirst(){
        int tt = opt.findFirst(places2,"Wolf Creek");
        assertEquals(tt,0);
    }
    @Test
    public void testadjustBasedOnFirst(){
        int[] p = {1,2,3};
        int f = 2;
        int[] dd = {10,12,50};
        int[] result = opt.adjustBasedOnFirst(p,f,dd);
        assertEquals(2,result[0]);
        assertEquals(3,result[1]);
        assertEquals(1,result[2]);
    }
    @Test
    public void testaddDistances(){
        int[] d = {250,150};
        int total = opt.addDistances(d);
        assertEquals(400,total);
    }
    @Test
    public void testbuildAdjacencyList(){
        List<Map<String, String>> places2 = new ArrayList<>();
        places2.add(m1);
        int[][] result = opt.buildAdjacencyList(places2,radius);
        assertEquals(result[0][0],0);

    }
    @Test
    public void printDebugAdj(){
        int[][] ad = new int[1][1];
        ad[0][0] = 0;
        assertEquals(opt.printDebugAdj(ad),"0");

    }

}