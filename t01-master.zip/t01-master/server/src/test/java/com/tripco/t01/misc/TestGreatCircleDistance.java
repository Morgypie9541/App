package com.tripco.t01.misc;


import java.util.*;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestGreatCircleDistance {
    double lat1;
    double lon1;
    double lat2;
    double lon2;
    GreatCircleDistance GCD = new GreatCircleDistance();
    double radius;

    @Before
    public void createGreatCircleTest(){
        lat1 = 50;
        lon1 = 50;
        lat2 = -50;
        lon2 = -50;
        radius = 3958.761316;

    }

    @Test
    public void  testHaversineFormula(){
        double result = GCD.haversineFormula(lat1,lon1,lat2,lon2,radius);
        assertEquals(result,9064.435134635403,1);

    }


}
