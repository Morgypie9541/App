package com.tripco.t01.TIP;

import com.google.gson.*;
import org.junit.Before;
import org.junit.Test;
import com.tripco.t01.misc.Optimizations;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.io.FileInputStream;
import java.io.File;

import static org.junit.Assert.assertEquals;

/** Verifies the operation of the TIP itinerary class and its buildResponse method.
 */

public class TestTIPItinerary {

    /* Radius and location values shared by test cases */
    private Map<String, String> titleAndRadius;
    private Map<String, Object> csu;
    private Map[] placesList;
    private final int version = 2;


    @Before
    public void createLocationsForTestCases() {
        titleAndRadius = new HashMap<>();
        titleAndRadius.put("title", "My Trip");
        titleAndRadius.put("earthRadius", "3958.761316");

        csu = new HashMap<>();
        csu.put("latitude", "40.576179");
        csu.put("longitude", "-105.080773");
        csu.put("name", "Oval, Colorado State University, Fort Collins, Colorado, USA");

        placesList =  new Map[1];
        placesList[0] = csu;
        }

    @Test
    public void testItinerarySame() {
        TIPItinerary trip = new TIPItinerary(version, titleAndRadius, placesList);
        trip.buildResponse();
        List<Integer> expect = new ArrayList<>();
        expect.add(0, 0);
        List<Integer> actual = trip.getDistances();
        assertEquals("itineraries match", expect, actual);
    }
    @Test
    public void testItineraryShort() {
        csu.put("optimization","short");
        TIPItinerary trip = new TIPItinerary(version, titleAndRadius, placesList);
        trip.buildResponse();
        List<Integer> expect = new ArrayList<>();
        expect.add(0, 0);
        List<Integer> actual = trip.getDistances();
        assertEquals("itineraries match", expect, actual);
    }

    }
