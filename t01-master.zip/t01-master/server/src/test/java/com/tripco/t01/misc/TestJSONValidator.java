package com.tripco.t01.misc;

import com.google.gson.*;
import com.tripco.t01.TIP.TIPFind;
//import com.tripco.t01.server.MicroServer;
import org.eclipse.jetty.http.HttpFields;
import org.eclipse.jetty.http.HttpVersion;
import org.junit.Before;
import org.junit.Test;


import static org.junit.Assert.assertEquals;

import com.tripco.t01.TIP.TIPConfig;
import com.tripco.t01.TIP.TIPDistance;
import com.tripco.t01.TIP.TIPItinerary;
import spark.Request;
import spark.Response;


public class TestJSONValidator
{
    //MicroServer server;

    private class MockRequest extends Request{
        private String JSONString;
        public MockRequest(String json){
            super();
            JSONString = json;
        }
        @Override
        public String body(){
            return JSONString;
        }
    }

    private class MockResponse extends Response{
        public MockResponse(){
            super();
        }
        public int statusCheck = 0;
        @Override
        public void status(int status){
            statusCheck = status;
        }
    }

    @Before
    public void setupServer(){
        //server = new MicroServer(31422);
    }

    @Test
    public void TestValidateDistance(){

        MockRequest distanceReq = new MockRequest(TestJSONStrings.validDistance);
        MockResponse distanceResp = new MockResponse();

      /*  server.processTIPrequest(TIPDistance.class, distanceReq, distanceResp);

        assertEquals(200, distanceResp.statusCheck);
*/

        boolean isValid = Validator.isValid(TestJSONStrings.validDistance, TIPDistance.class);
//        assert(isValid);

        isValid = Validator.isValid(TestJSONStrings.emptyString, TIPDistance.class);
        assert(!isValid);
    }

    @Test
    public void TestValidateItinerary(){


        boolean isValid = Validator.isValid(TestJSONStrings.validItinerary, TIPItinerary.class);
        assert(isValid);

        isValid = Validator.isValid(TestJSONStrings.emptyString, TIPItinerary.class);
        assert(!isValid);
    }


    public void TestValidateConfig(){
        boolean isValid = Validator.isValid(TestJSONStrings.validConfig, TIPConfig.class);
        assert(isValid);

        isValid = Validator.isValid(TestJSONStrings.emptyString, TIPConfig.class);
        assert(!isValid);
    }

    @Test
    public void TestValidateFind(){
        boolean isValid = Validator.isValid(TestJSONStrings.validFind, TIPFind.class);
        assert(isValid);

        isValid = Validator.isValid(TestJSONStrings.emptyString, TIPFind.class);
        assert(!isValid);
    }

}
