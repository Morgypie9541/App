package com.tripco.t01.misc;

public class TestJSONStrings {

     public static final String OptimizationTest ="{ \"requestType\": \"itinerary\", \"requestVersion\": 3, \"options\":"+
             "{ \"title\": \"My Trip\", \"earthRadius\": \"3958.761316\", \"optimizations\": \"short\" }, \"places\": "+
        "[{\"id\": \"dnvr\",\"name\": \"Denver\",\"latitude\": \"39.7392\",\"longitude\": \"-104.9903\"}, "+
             "{\"id\": \"bldr\",\"name\": \"Boulder\",\"latitude\": \"40.01499\",\"longitude\": \"-105.27055\"}, "+
             "{\"id\": \"cosp\",\"name\": \"Colorado Springs\",\"latitude\": \"38.8339\",\"longitude\": \"-104.8214\"},"+
             "{\"id\": \"foco\",\"name\": \"Fort Collins\",\"latitude\": \"40.585258\",\"longitude\": \"-105.084419\"}, "+
             "{\"id\": \"pueb\",\"name\": \"Pueblo\",\"latitude\": \"38.2544\",\"longitude\": \"-104.6091\"} ], \"distances\": [] }\n";

     public static final String emptyString = "";

     public static final String emptyJSON = "{}";

     public static final String validDistance = "{\n" +
            "  \"requestType\"    : \"distance\",\n" +
            "  \"requestVersion\" : 3,\n" +
            "  \"origin\"         : {\"latitude\":  \"40.6\", \"longitude\": \"-105.1\", \"name\":\"Fort Collins, Colorado, USA\"},\n" +
            "  \"destination\"    : {\"latitude\": \"-33.9\", \"longitude\":  \"151.2\", \"name\":\"Sydney, New South Wales, Australia\"},\n" +
            "  \"earthRadius\"    : 3958.8,\n" +
            "  \"distance\"       : 0\n" +
            "}";

     public static final String validConfig = "{\n" +
             "  \"requestType\"        : \"config\",\n" +
             "  \"requestVersion\"     : 3,\n" +
             "  \"serverName\"         : \"t## name\",\n" +
             "  \"placeAttributes\"    : [\"name\", \"latitude\", \"longitude\", \"id\", \"municipality\", \"altitude\"],\n" +
             "  \"optimizations\"      : [\"none\",\"short\"]\n" +
             "}";

     public static final String validEmptyItinerary = "{\n" +
             "  \"requestType\"    : \"itinerary\",\n" +
             "  \"requestVersion\" : 3,\n" +
             "  \"options\"        : {},\n" +
             "  \"places\"         : [],\n" +
             "  \"distances\"      : []\n" +
             "}";

     public static final String validItinerary = "{\n" +
             "  \"requestType\"    : \"itinerary\",\n" +
             "  \"requestVersion\" : 3,\n" +
             "  \"options\"        : { \"title\":\"My Trip\", \n" +
             "                       \"earthRadius\":\"3958.8\",\n" +
             "                       \"optimization\":\"none\" },\n" +
             "  \"places\"         : [{\"name\":\"Denver\",       \"latitude\": \"39.7\", \"longitude\": \"-105.0\"},\n" +
             "                      {\"name\":\"Boulder\",      \"latitude\": \"40.0\", \"longitude\": \"-105.4\"},\n" +
             "                      {\"name\":\"Fort Collins\", \"latitude\": \"40.6\", \"longitude\": \"-105.1\"}],\n" +
             "  \"distances\"      : [24, 41, 59]\n" +
             "}";

     public static final String validItineraryWithOpti = "{\n" +
             "  \"requestType\"    : \"itinerary\",\n" +
             "  \"requestVersion\" : 3,\n" +
             "  \"options\"        : { \"title\":\"My Trip\", \n" +
             "                       \"earthRadius\":\"3958.8\",\n" +
             "                       \"optimization\":\"short\" },\n" +
             "  \"places\"         : [{\"name\":\"Denver\",       \"latitude\": \"39.7\", \"longitude\": \"-105.0\"},\n" +
             "                      {\"name\":\"Boulder\",      \"latitude\": \"40.0\", \"longitude\": \"-105.4\"},\n" +
             "                      {\"name\":\"Fort Collins\", \"latitude\": \"40.6\", \"longitude\": \"-105.1\"}],\n" +
             "  \"distances\"      : [24, 41, 59]\n" +
             "}";

     public static final String validEmptyFind = "{\n" +
             "  \"requestType\"    : \"find\",\n" +
             "  \"requestVersion\" : 3,\n" +
             "  \"match\"          : \"\",\n" +
             "  \"limit\"          : 0,\n" +
             "  \"found\"          : 0,\n" +
             "  \"places\"         : []\n" +
             "}";

     public static final String validFind = "{\n" +
             "  \"requestType\"    : \"find\",\n" +
             "  \"requestVersion\" : 3,\n" +
             "  \"match\"          : \"fort\",\n" +
             "  \"limit\"          : 1,\n" +
             "  \"found\"          : 123,\n" +
             "  \"places\"         : [{\"name\":\"Fort Collins\", \"latitude\": \"40.6\", \"longitude\": \"-105.1\"}]\n" +
             "}";


     public static final String getBreweriesItinerary = "{\n" +
          "\t\"requestType\": \"itinerary\",\n" +
          "\t\"requestVersion\": 2,\n" +
          "\t\"options\": {\n" +
          "\t\t\"title\": \"My Trip\",\n" +
          "\t\t\"earthRadius\": \"3958.761316\"\n" +
          "\t},\n" +
          "\t\"places\": [\n" +
          "      {\"id\": \"first\", \"name\":\"Rock Bottom Brewery\", \"municipality\":\"Denver\", \"latitude\":\"39.7475\", \"longitude\":\"-104.9947\", \"altitude\":\"5209\"}\n" +
          "      ,{\"id\": \"whiteaj\", \"name\":\"SomePlace Else Brewing\", \"municipality\":\"Arvada\", \"latitude\":\"39.7917\", \"longitude\":\"-105.0678\", \"altitude\":\"5453\"}\n" +
          "      ,{\"id\":\"kyoussef\",\"name\":\"300 Suns Brewing\",\"municipality\":\"Longmont\",\"latitude\":\"38.4254\",\"longitude\":\"-104.5424\",\"altitude\":\"5321\"}\n" +
          "      ,{\"id\": \"jlopez63\", \"name\": \"Spice Trade Brewing\", \"municipality\": \"Arvada\", \"latitude\": \"39.8023\", \"longitude\": \"-105.0841\", \"altitude\": \"5360\"}\n" +
          "      ,{\"id\": \"cseew99\", \"name\":\"Dad & Dudes Breweria\", \"municipality\":\"Aurora\", \"latitude\":\"39.5940\", \"longitude\":\"-104.8063\", \"altitude\":\"5656\"}\n" +
          "      ,{\"id\": \"msfales\", \"name\":\"Dry Dock Brewing Company\", \"municipality\":\"Aurora\", \"latitude\":\"39.653177\", \"longitude\":\"-104.811955\", \"altitude\":\"5709\"}\n" +
          "      ,{\"id\": \"bommarit\", \"name\":\"Launch Pad Brewery\", \"municipality\":\"Aurora\", \"latitude\":\"39.701030\", \"longitude\":\"-104.790850\", \"altitude\":\"5531\"}\n" +
          "      ,{\"id\": \"gstamand\", \"name\":\"Ursula Brewery\", \"municipality\":\"Aurora\", \"latitude\":\"39.4451\", \"longitude\":\"-104.5018\", \"altitude\":\"5358 \" }\n" +
          "      ,{\"id\": \"leepat\", \"name\": \"New Planet Beer\", \"municipality\": \"Boulder\", \"latitude\": \"40.0251\", \"longitude\": \"-105.1650\", \"altitude\": \"5509\"}\n" +
          "      ,{\"id\": \"jaylizz\", \"name\":\"Twisted Pine Brewing Company\", \"municipality\":\"Boulder\", \"latitude\":\"40.0206\", \"longitude\":\"-105.2510\", \"altitude\":\"5283\"}\n" +
          "      ,{\"id\": \"wnr210\", \"name\":\"Walnut Brewery\", \"municipality\":\"Boulder\", \"latitude\":\"40.0169\", \"longitude\":\"-105.2803\", \"altitude\":\"5456\"}\n" +
          "      ,{\"id\": \"jjbrad\", \"name\":\"Breckenridge Brewery & Pub\", \"municipality\":\"Breckenridge\", \"latitude\":\"39.4761\", \"longitude\":\"-106.0437\", \"altitude\":\"9629\"}\n" +
          "      ,{\"id\": \"ecouniha\", \"name\":\"Broken Compass Brewing\", \"municipality\":\"Breckenridge\", \"latitude\":\"39.5148\", \"longitude\":\"-106.0534\", \"altitude\":\"9383\"}\n" +
          "      ,{\"id\": \"masforce\", \"name\":\"4 Noses Brewing Company\", \"municipality\":\"Broomfield\", \"latitude\":\"39.9064\", \"longitude\":\"-105.0979\", \"altitude\":\"5420\"}\n" +
          "      ,{\"id\": \"jwelch31\",\"name\": \"Nighthawk Brewery\",\"municipality\": \"Broomfield\",\"latitude\": \"39.5514\",\"longitude\": \"-105.0604\",\"altitude\": \"5463\"}\n" +
          "      ,{\"id\": \"andreh\", \"name\":\"Wonderland Brewing\", \"municipality\":\"Broomfield\", \"latitude\":\"39.9133224\", \"longitude\":\"-105.0558566\", \"altitude\":\"5310\"}\n" +
          "      ,{\"id\": \"joshtburris\", \"name\": \"Roaring Fork Beer Company\", \"municipality\": \"Carbondale\", \"latitude\": \"39.4106\", \"longitude\": \"-107.2236\", \"altitude\": \"6136\"}\n" +
          "      ,{\"id\": \"kshaffne\", \"name\":\"Rockyard Brewing Company\", \"municipality\":\"Castle Rock\", \"latitude\":\"39.4104\", \"longitude\":\"-104.8708\", \"altitude\":\"6244\"}\n" +
          "      ,{\"id\": \"abautin\",\"name\": \"4 B's Brewery\",\"municipality\": \"Cedaredge\",\"latitude\": \"38.5401\",\"longitude\": \"-107.5551\",\"altitude\": \"6131\"}\n" +
          "      ,{\"id\": \"jtopps\", \"name\":\"Two22 Brew\", \"municipality\":\"Centennial\", \"latitude\":\"39.636042\", \"longitude\":\"-104.758698\", \"altitude\":\"5797\"}\n" +
          "      ,{\"id\": \"simonnardos\",\"name\": \"Bristol Brewing Company\",\"municipality\": \"Colorado Springs\",\"latitude\": \"38.8112\",\"longitude\": \"-104.8274\",\"altitude\": \"5991\"}\n" +
          "      ,{\"id\": \"jratliff\", \"name\":\"Smiling Toad Brewery\", \"municipality\":\"Colorado Springs\", \"latitude\":\"38.806808\", \"longitude\":\"-104.838562\", \"altitude\":\"6017\"}\n" +
          "      ,{\"id\": \"shzhu\", \"name\":\"Whistle Pig Brewing Company\", \"municipality\":\"Colorado Springs\", \"latitude\":\"38.924064\", \"longitude\":\"-104.792772\", \"altitude\":\"6432\"}\n" +
          "      ,{\"id\": \"toddm\", \"name\": \"Storybook Brewing\", \"municipality\": \"Colorado Springs\", \"latitude\": \"38.88\",\"longitude\": \"104.81\", \"altitude\": \"6158\"}\n" +
          "      ,{\"id\": \"javander\", \"name\":\"Irwin Brewing Company\", \"municipality\":\"Crested Butte\", \"latitude\":\"38.8668\", \"longitude\":\"-106.9851\", \"altitude\":\"8888\"}\n" +
          "      ,{\"id\": \"jgelfand\", \"name\":\"10 Barrel Brewing Company\", \"municipality\":\"Denver\", \"latitude\":\"39.76\", \"longitude\":\"-104.99\", \"altitude\":\"5220\"}\n" +
          "      ,{\"id\": \"dsant8\", \"name\":\"Black Shirt Brewing Co\", \"municipality\":\"Denver\", \"latitude\":\"36.4611\", \"longitude\":\"104.5822\", \"altitude\":\"5207\"}\n" +
          "      ,{\"id\": \"yaobingn\", \"name\":\"Can't Stop Brewing\", \"municipality\":\"Denver\", \"latitude\":\"39.7123\", \"longitude\":\"-105.0060\", \"altitude\":\"5217\"}\n" +
          "      ,{\"id\": \"wqi\",\"name\": \"Goldspot Brewing Company\",\"municipality\": \"Denver\",\"latitude\": \"39.786889\",\"longitude\": \"-105.03433\",\"altitude\": \"5379\"}\n" +
          "      ,{\"id\": \"tprooney\", \"name\":\"Grandma's House\", \"municipality\":\"Denver\", \"latitude\":\"39.6854\", \"longitude\":\"-104.9871\", \"altitude\":\"5284\"}\n" +
          "      ,{\"id\": \"mpaczosa\", \"name\": \"joyride brewing company\", \"municipality\": \"Denver\", \"latitude\": \"39.753365\", \"longitude\": \"-105.053474\", \"altitude\": \"5332\"}\n" +
          "      ,{\"id\": \"cjross\", \"name\":\"Lowdown Brewery\", \"municipality\":\"Denver\", \"latitude\":\"39.729301\", \"longitude\":\"-104.985763\", \"altitude\":\"5262\"}\n" +
          "      ,{\"id\": \"epike919\", \"name\":\"Mockery Brewing\", \"municipality\":\"Denver\", \"latitude\":\"39.7711\", \"longitude\":\"-104.9797\", \"altitude\":\"5187\"}\n" +
          "      ,{\"id\": \"asoto98\",\"name\": \"Oasis Brewing Company\",\"municipality\": \"Denver\",\"latitude\": \"39.7632\",\"longitude\": \"-105.0347\",\"altitude\": \"5394\"}\n" +
          "      ,{\"id\": \"brandokid\", \"name\":\"Prost Brewing Company\", \"municipality\":\"Denver\", \"latitude\":\"39.7614\", \"longitude\":\"-105.0066\", \"altitude\":\"5220\"}\n" +
          "      ,{\"id\": \"chengxi\", \"name\":\"River North Brewery\", \"municipality\":\"Denver\", \"latitude\":\"39.806565\", \"longitude\":\"-104.997908\", \"altitude\":\"5195\"}\n" +
          "      ,{\"id\": \"jeremycl\", \"name\":\"Wit's End Brewing Company\",\"municipality\":\"Denver\", \"latitude\":\"39.2202\", \"longitude\":\"-105.0147\", \"altitude\":\"5203\"}\n" +
          "      ,{\"id\": \"sbhuju\", \"name\":\"Zuni Street Brewing Company\", \"municipality\":\"Denver\", \"latitude\":\"39.758701\", \"longitude\":\"-105.015254\", \"altitude\":\"5279\"}\n" +
          "      ,{\"id\": \"mnenirq\", \"name\": \"Zuni Street Brewing Company\", \"municipality\": \"Denver\", \"latitude\": \"38.7585929\", \"longitude\": \"-105.015409\", \"altitude\": \"5278\"}\n" +
          "      ,{\"id\": \"dyplomon\", \"name\":\"Animas Brewing Company\", \"municipality\":\"Durango\", \"latitude\":\"37.28\", \"longitude\":\"-107.88\", \"altitude\":\"6522\"}\n" +
          "      ,{\"id\": \"bhoyt\", \"name\":\"Ska Brewing Co\", \"municipality\":\"Durango\", \"latitude\":\"37.2388\", \"longitude\":\"-107.8761\", \"altitude\":\"6565\"}\n" +
          "      ,{\"id\": \"gusn\", \"name\":\"Industrial Revolution Brewing Company\", \"municipality\":\"Erie\", \"latitude\":\"40.051874\", \"longitude\":\"-105.048654\", \"altitude\":\"5130\"}\n" +
          "      ,{\"id\": \"johnsnm\", \"name\": \"Estes Park Brewery\", \"municipality\": \"Estes Park\", \"latitude\": \"40.3714\", \"longitude\": \"-105.5261\", \"altitude\": \"7522\"}\n" +
          "      ,{\"id\": \"rzwisler\", \"name\":\"Lumpy Ridge Brewing Company\", \"municipality\":\"Estes Park\", \"latitude\":\"40.3692\", \"longitude\":\"-105.5047\", \"altitude\":\"7612\"}\n" +
          "      ,{\"id\": \"dacline\", \"name\":\"Southpark Brewing Company\", \"municipality\":\"Fairplay\", \"latitude\":\"39.2201\", \"longitude\":\"-105.9933\", \"altitude\":\"9862\"}\n" +
          "      ,{\"id\": \"kpashak\", \"name\": \"Black Bottle Brewery\", \"municipality\": \"Fort Collins\", \"latitude\": \"40.57\",\"longitude\": \"-105.08\", \"altitude\": \"5003\"}\n" +
          "      ,{\"id\": \"pmsulliv\", \"name\":\"Coopersmith's pub and Brewing\", \"municipality\" : \"Fort Collins\", \"latitude\":\"40.5\", \"longitude\" : \"-105.0\", \"altitude\": \"4930\"}\n" +
          "      ,{\"id\": \"calebt\", \"name\":\"Equinox Brewing\", \"municipality\":\"Fort Collins\", \"latitude\":\"40.5864\", \"longitude\":\"-105.0758\", \"altitude\":\"4986\"}\n" +
          "      ,{\"id\": \"mgonzo\", \"name\":\"Funkwerks\", \"municipality\":\"Fort Collins\", \"latitude\":\"40.3453\", \"longitude\":\"-105.0255\", \"altitude\":\"4921\"}\n" +
          "      ,{\"id\": \"willyomcd\", \"name\":\"Gilded Goat\", \"municipality\":\"Fort Collins\", \"latitude\":\"40.5396\", \"longitude\":\"-105.0754\", \"altitude\":\"5026\"}\n" +
          "      ,{\"id\": \"waynemw\", \"name\":\"Maxline Brewing\", \"municipality\":\"Fort Collins\", \"latitude\":\"40.5497\", \"longitude\":\"-105.0797\", \"altitude\":\"5026\"}\n" +
          "      ,{\"id\": \"JylosGoldwing\", \"name\":\"New Belgium Brewery\", \"municipality\":\"Fort Collins\", \"latitude\":\"40.5591\", \"longitude\":\"-105.0781\", \"altitude\":\"5003\"}\n" +
          "      ,{\"id\": \"njodell\", \"name\":\"Odell Brewing Company\", \"municipality\":\"Fort Collins\",  \"latitude\":\"40.58878\",  \"longitude\":\"-105.06025\", \"altitude\":\"4960\"}\n" +
          "      ,{\"id\": \"cakitten\", \"name\":\"Rally King Brewing\", \"municipality\":\"Fort Collins\", \"latitude\":\"40.5661\", \"longitude\":\"-105.0568\", \"altitude\":\"4940\"}\n" +
          "      ,{\"id\": \"psben113\", \"name\":\"Gilded Goat Brewing Company\", \"municipality\":\"Fort Collins\", \"latitude\":\"40.5393\", \"longitude\":\"-105.0752\", \"altitude\":\"5013\"}\n" +
          "      ,{\"id\": \"crcolema\",\"name\": \"Snowbank Brewery\",\"municipality\": \"Fort Collins\",\"latitude\": \"40.5899\",\"longitude\": \"-105.0583\",\"altitude\": \"4930\"}\n" +
          "      ,{\"id\": \"cwiegand\", \"name\":\"Echo Brewing Company\", \"municipality\":\"Frederick\", \"latitude\":\"40.1116\", \"longitude\": \"-104.9452\", \"altitude\":\"4970\"}\n" +
          "      ,{\"id\": \"alzamily\", \"name\":\"Suds Brothers Brewing\", \"municipality\":\"Fruita\", \"latitude\":\"39.1592\", \"longitude\":\"-108.7327\", \"altitude\":\"4514\"}\n" +
          "      ,{\"id\": \"hives\", \"name\":\"Barrels & Bottles Brewery\", \"municipality\":\"Golden\", \"latitude\":\"36.4522\", \"longitude\":\"-105.1310\", \"altitude\":\"5653\"}\n" +
          "      ,{\"id\": \"wscarbro\",\"name\": \"Golden City Brewery\",\"municipality\": \"Golden\",\"latitude\": \"39.75467\",\"longitude\": \"-105.2236\",\"altitude\": \"5650\"}\n" +
          "      ,{\"id\": \"zackaryj\", \"name\":\"Edgewater Brewery\", \"municipality\":\"Grand Junction\", \"latitude\":\"39.0549\", \"longitude\":\"-108.5573\", \"altitude\":\"4566\"}\n" +
          "      ,{\"id\": \"dziugas\", \"name\":\"WeldWerks Brewing Co.\", \"municipality\":\"Greeley\", \"latitude\":\"40.4281\", \"longitude\":\"-104.6905\", \"altitude\":\"4669\"}\n" +
          "      ,{\"id\": \"futuration\", \"name\": \"Yampa Valley Brewing Company\", \"municipality\": \"Hayden\", \"latitude\": \"40.495810\",\"longitude\": \"-107.257628\", \"altitude\": \"6345\"}\n" +
          "      ,{\"id\": \"junyiliu\", \"name\":\"Odd 13 Brewing\", \"municipality\":\"Lafayette\", \"latitude\":\"39.9986\", \"longitude\":\"-105.0879\", \"altitude\":\"5236\"}\n" +
          "      ,{\"id\": \"elavertu\", \"name\": \"Lone Tree Brewing Company\", \"municipality\": \"Lone Tree\", \"latitude\": \"39.5627\", \"longitude\": \"-104.8929\", \"altitude\": \"5948\"}\n" +
          "      ,{\"id\": \"jhfitzg\", \"name\":\"Bootstrap Brewing Company\", \"municipality\":\"Longmont\", \"latitude\":\"40.1615\", \"longitude\":\"-105.1063\", \"altitude\":\"4967\"}\n" +
          "      ,{\"id\": \"griffgil\", \"name\":\"Left Hand Brewing Company\",\"municipality\":\"Longmont\", \"latitude\":\"40.1583\", \"longitude\":\"-105.0638\", \"altitude\":\"4967\"}\n" +
          "      ,{\"id\": \"chaney\", \"name\":\"Oskar Blues Brewery\", \"municipality\":\"Longmont\", \"latitude\":\"40.2243812\", \"longitude\":\"-105.2707522\", \"altitude\":\"5012\"}\n" +
          "      ,{\"id\": \"mpopesh\", \"name\":\"Shoes & Brews\", \"municipality\":\"Longmont\", \"latitude\":\"40.1581\", \"longitude\":\"-105.1075\", \"altitude\":\"4950\"}\n" +
          "      ,{\"id\": \"suchiv\",\"name\": \"Crystal Springs Brewing Company\",\"municipality\": \"Louisville\",\"latitude\": \"39.57\",\"longitude\": \"-105.07\",\"altitude\": \"5328\"}\n" +
          "      ,{\"id\": \"jlham\", \"name\":\"Grimm Brothers Brewhouse\", \"municipality\":\"Loveland\", \"latitude\":\"40.3968\", \"longitude\":\"-105.0469\", \"altitude\":\"4962\"}\n" +
          "      ,{\"id\": \"dcooke\", \"name\":\"Verboten Brewing\", \"municipality\":\"Loveland\", \"latitude\":\"40.397151\", \"longitude\":\"-105.075028\", \"altitude\":\"4982\"}\n" +
          "      ,{\"id\": \"fengwang\", \"name\":\"Manitou Brewing Company\", \"municipality\":\"Manitou Springs\", \"latitude\":\"38.5131\", \"longitude\":\"-104.5505\", \"altitude\":\"6342\"}\n" +
          "      ,{\"id\": \"kwelsh\", \"name\":\"Very Nice Brewing Company\", \"municipality\":\"Nederland\", \"latitude\":\"39.9605776\", \"longitude\":\"-105.507509\", \"altitude\":\"8243\"}\n" +
          "      ,{\"id\": \"azmarque\", \"name\":\"Ouray Brewery\", \"municipality\":\"Ouray\", \"latitude\":\"38.0122\", \"longitude\":\"-107.4016\", \"altitude\":\"7788\"}\n" +
          "      ,{\"id\": \"tsciano\", \"name\":\"Pagosa Brewing Company\", \"municipality\":\"Pagosa Springs\", \"latitude\":\"37.2552227\", \"longitude\":\"-107.0803194\", \"altitude\":\"7523\"}\n" +
          "      ,{\"id\": \"maroe\",\"name\":\"Revolution Brewing\",\"municipality\":\"Paonia\",\"latitude\":\"38.868921\",\"longitude\":\"-107.597381\",\"altitude\":\"5682\"}\n" +
          "      ,{\"id\": \"fbworm\", \"name\": \"Barnett & Son Brewing\", \"municipality\": \"Parker\", \"latitude\": \"39.5223\", \"longitude\": \"-104.775\", \"altitude\": \"5834\"}\n" +
          "      ,{\"id\": \"ehendricks99\", \"name\":\"Walter Brewing Company\", \"municipality\":\"Pueblo\", \"latitude\":\"38.2623\", \"longitude\":\"-104.6102\", \"altitude\":\"4656\"}\n" +
          "      ,{\"id\":\"pkeleher\", \"name\": \"Colorado Boy Pub & Brewery\", \"municipality\": \"Ridgway\", \"latitude\": \"38.152587\", \"longitude\": \"-107.757803\", \"altitude\":\"6985\"}\n" +
          "      ,{\"id\": \"arwatts\", \"name\":\"Dead Hippie Brewery\", \"municipality\":\"Sheridan\", \"latitude\":\"39.6491\", \"longitude\":\"-105.0040\", \"altitude\":\"5325\"}\n" +
          "      ,{\"id\": \"mdschulz\", \"name\":\"Avalanche Brewing Company\", \"municipality\":\"Silverton\", \"latitude\":\"37.8105\", \"longitude\":\"-107.6646\", \"altitude\":\"9318\"}\n" +
          "      ,{\"id\": \"bgratias\", \"name\": \"Butcherknife Brewing Company\", \"municipality\": \"Steamboat Springs\", \"latitude\": \"40.5108\", \"longitude\": \"-106.8582\", \"altitude\": \"6726\"}\n" +
          "      ,{\"id\": \"wdomier\",\"name\": \"Mohogany Ridge Brewery\",\"municipality\": \"Steamboat Springs\",\"latitude\": \"40.483736\",\"longitude\": \"-106.831351\",\"altitude\": \"6736\"}\n" +
          "      ,{\"id\": \"ncz\", \"name\":\"Mountain Tap Brewery\", \"municipality\":\"Steamboat Springs\", \"latitude\":\"40.4866\", \"longitude\":\"-106.8371\", \"altitude\":\"6732\"}\n" +
          "      ,{\"id\": \"danielr\", \"name\":\"Steamboat BrauHaus\", \"municipality\":\"Steamboat Springs\", \"latitude\":\"40.4551\", \"longitude\":\"-106.8047\", \"altitude\":\"6854\"}\n" +
          "      ,{\"id\": \"millardk\", \"name\":\"Storm Peak Brewing Company\", \"municipality\":\"Steamboat Springs\", \"latitude\":\"40.5021\", \"longitude\":\"-106.8549\", \"altitude\":\"6700\"}\n" +
          "      ,{\"id\": \"cgessama\", \"name\":\"Smuggler's Brewpub\", \"municipality\":\"Telluride\", \"latitude\":\"37.935746\", \"longitude\":\"-107.811668\", \"altitude\":\"8756\"}\n" +
          "      ,{\"id\": \"wstnmssr\", \"name\":\"Mother Tucker Brewery\", \"municipality\":\"Thornton\", \"latitude\":\"39.9133\", \"longitude\":\"-104.9562\", \"altitude\":\"5227\"}\n" +
          "      ,{\"id\": \"mfvera\", \"name\": \"Kokopelli Beer Company\", \"municipality\": \"Westminster\", \"latitude\": \"39.85775\", \"longitude\": \"-105.06389\", \"altitude\": \"5462\"}\n" +
          "      ,{\"id\": \"gaddvi\",\"name\": \"Colorado Plus\",\"municipality\": \"Wheat Ridge\",\"latitude\": \"39.77\",\"longitude\": \"-105.07\",\"altitude\": \"5413\"}\n" +
          "      ,{\"id\": \"jtperea\", \"name\":\"High Hops Brewery\", \"municipality\":\"Windsor\", \"latitude\":\"40.480744\", \"longitude\":\"-104.935592\", \"altitude\":\"4793\"}\n" +
          "      ,{\"id\": \"kwimer\", \"name\":\"Mighty River Brewing Company\", \"municipality\":\"Windsor\", \"latitude\":\"40.457224\", \"longitude\":\"-104.982153\", \"altitude\":\"5013\"}\n" +
          "      ,{\"id\": \"cupit\", \"name\":\"Hideaway Park Brewery\", \"municipality\":\"Winter Park\", \"latitude\":\"39.9181\", \"longitude\":\"-105.7842\", \"altitude\":\"8799\"}\n" +
          "      ,{\"id\": \"zachklau\", \"name\":\"Ute Pass Brewing\", \"municipality\":\"Woodland Park\", \"latitude\":\"38.99\", \"longitude\":\"-105.05\", \"altitude\":\"8448\"}\n" +
          "      ,{\"id\": \"last\", \"name\":\"Horse and Dragon Brewing\", \"municipality\":\"Fort Collins\", \"latitude\":\"40.5894\", \"longitude\":\"-105.0455\", \"altitude\":\"4944\"}\n" +
          "      ,{\"id\": \"davematt\", \"name\":\"Steamworks Brewing Company\", \"municipality\":\"Durango\", \"latitude\":\"37.2722\", \"longitude\":\"-107.8797\", \"altitude\":\"6566\"}\n" +
          "      ,{\"id\": \"sswensen\", \"name\":\"Vail Brewing Company\", \"municipality\":\"Vail\", \"latitude\":\"39.6206\", \"longitude\":\"-106.4697\", \"altitude\":\"9261\"}\n" +
          "      ,{\"id\": \"mnenirq\", \"name\": \"Zuni Street Brewing Company\", \"municipality\": \"Denver\", \"latitude\": \"38.7585929\", \"longitude\": \"-105.015409\", \"altitude\": \"5278\"}\n" +
          "  ],\n" +
          "\t\"distances\": []\n" +
          "}\n";

}
