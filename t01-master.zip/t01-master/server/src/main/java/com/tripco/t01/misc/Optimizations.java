package com.tripco.t01.misc;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Optimizations {

    /*
     * Makes trip shorter
     * */
    public static List<Map<String,String>> MakeTripShorter(List<Map<String,String>> places, String firstPlace, double radius, List<Integer> distances){

        List<Map<String,String>> newPlaces = new ArrayList<>();
        int[][] adjList = buildAdjacencyList(places, radius);
        int length = adjList.length;

        int[] savedPlaces = new int[length];
        int[] savedDistances = new int[length];
        int smallestTotal = Integer.MAX_VALUE;
        for(int i = 0; i < length;i++){
            int[] tempDistances = new int[length];
            int[] reorderedPlaces = nNAlgo(adjList, i, tempDistances);
            int total = addDistances(tempDistances);
            if(total < smallestTotal){
                smallestTotal = total;
                savedDistances = tempDistances;
                savedPlaces = reorderedPlaces;
            }
        }
        int firstIndex = 0;
        if(!firstPlace.isEmpty()) {
            firstIndex = findFirst(places, firstPlace);
        }
        savedPlaces = adjustBasedOnFirst(savedPlaces, firstIndex, savedDistances);

        for(int x : savedPlaces) {
            newPlaces.add(places.get(x));
        }
        for(int x : savedDistances) {
            distances.add(x);
        }
        return newPlaces;
    }

    public static int addDistances(int[] distances){
        int total = 0;
        for(int x : distances){
            total+=x;
        }
        return total;
    }

    /*
     * Reorders the indexes of the places list using the nearest neighbor algorithm
     * */
    public static int[] nNAlgo(int[][] adjList, int firstPlace, int[] distances){

        boolean[] visited = new boolean[adjList.length]; //default init as false

        int[] indexOrderedInPlaces = new int[adjList.length];
        //add first city
        indexOrderedInPlaces[0] = firstPlace;
        visited[firstPlace] = true;

        int previousCity = firstPlace;
        for(int orderIndex = 1; orderIndex < indexOrderedInPlaces.length; orderIndex++){
            int smallest = Integer.MAX_VALUE;
            int smallestIndex = -1;
            //find city with smallest distance that has not been visited
            for(int nextCity = 0; nextCity < adjList[previousCity].length;nextCity++){
                if(adjList[previousCity][nextCity] < smallest) {
                    if(previousCity != nextCity) {
                        if(!visited[nextCity]){//make sure not to take the 0 distance of same city
                            smallest = adjList[previousCity][nextCity]; //this is distance
                            smallestIndex = nextCity;
                        }
                    }
                }
            }
            //if -1, no city was found. guaranteed all cities have been visited
            if(smallestIndex != -1) {
                visited[smallestIndex] = true;
                indexOrderedInPlaces[orderIndex] = smallestIndex;
                previousCity = smallestIndex;
                distances[orderIndex-1] = smallest;
            }
        }
        int lastPlace = indexOrderedInPlaces[indexOrderedInPlaces.length-1];
        distances[distances.length-1] = adjList[firstPlace][lastPlace];
        return indexOrderedInPlaces;
    }

    /*
     * find the index of name in the places list. return the first city if no match is found
     * */
    public static int findFirst(List<Map<String,String>> places, String name){
        int index = 0;
        for(Map<String,String> x : places){
            if(x.get("name").equals(name)) {
                break;
            }
            index++;
        }
        if(index >= places.size())
            return 0;
        else
            return index;
    }

    /*
     * If supplied with a different first city, adjust cities with the
     * first city as the desired first city
     * tours are cyclic, no need to change the order.
     * */
    public static int[] adjustBasedOnFirst(int[] places, int firstIndex, int[] distances) {
        int length = places.length;
        int[] reorderedPlaces = new int[length];
        int[] reOrderedDistances = new int[length];
        //find index of firstIndex in the new reordered places
        for(int i = 0; i < length;i++){
            if(places[i] == firstIndex){
                firstIndex = i;
                break;
            }
        }
        //copy into new array starting with firstIndex
        for(int index = 0; index < length; index++){
            reorderedPlaces[index] = places[firstIndex];
            reOrderedDistances[index] = distances[firstIndex];
            firstIndex++;
            if(firstIndex >= length) {
                firstIndex = 0;
            }
        }
        for(int i = 0; i < length; i++) {
            distances[i] = reOrderedDistances[i];
        }
        return reorderedPlaces;
    }

    /*
     * Calculates and save distances between each city.
     * */
    public static int[][] buildAdjacencyList(List<Map<String,String>> places, double radius){
        int[][] adj = new int[places.size()][places.size()];

        for(int i = 0; i<places.size();i++){
            for(int j = 0; j<places.size();j++){
                Map<String,String> myMap = places.get(i);
                Map<String,String> myMap2 = places.get(j);
                adj[i][j] = (int) GreatCircleDistance.haversineFormula(
                            Double.parseDouble(String.valueOf(myMap.get("latitude"))),
                            Double.parseDouble(String.valueOf(myMap.get("longitude"))),
                            Double.parseDouble(String.valueOf(myMap2.get("latitude"))),
                            Double.parseDouble(String.valueOf(myMap2.get("longitude"))),
                            radius
                );

            }
        }
        return adj;
    }

    /*
     * Debug only, visual representation of the adjacency list
     * */
    public static String printDebugAdj(int[][] adj){
        String S = "0";
        for(int i = 0; i < adj.length;i++){
            for(int j = 0; j < adj[i].length;j++){
                S = String.format("%d ",adj[i][j]);
            }
            //System.out.println();
        }
        return "0";
    }

}
