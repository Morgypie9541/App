package com.tripco.t01.TIP;

import com.tripco.t01.misc.GreatCircleDistance;
import com.tripco.t01.misc.Optimizations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class TIPItinerary extends TIPHeader{
    private Map options;
    private Map[] places;
    private List<Integer> distances;

    private final transient Logger log = LoggerFactory.getLogger(TIPItinerary.class);

    TIPItinerary(){
        this.requestType = "itinerary";
        this.requestVersion=5;
    }

    TIPItinerary(int requestVersion, Map options, Map[] places){
        this();
        this.requestVersion = requestVersion;
        this.options = options;
        this.places = places;
        this.distances = null;
    }

    @Override
    public void buildResponse() {
        this.distances = new ArrayList<>();

        if(options.get("optimization") != null)
            if(options.get("optimization").equals("Short")) {
                this.distances = CalculateDistances(places, options);
                //add new data structure to fit Optimization function(map[] to List<map>) & (List<double> to List<int>)
                List<Map<String,String>> myList = new ArrayList<>();
                for(int i = 0; i < places.length;++i){
                    myList.add(places[i]); }

                List<Integer> cD = new ArrayList<>();
                for(int i = 0; i < distances.size();++i) {
                    cD.add( (int) Math.round(distances.get(i))); }

                //parse earth radius to double from string object and do optimization
                double d = Double.parseDouble(options.get("earthRadius").toString());
                myList = Optimizations.MakeTripShorter(myList, "",d, cD);

                //transform back into map[] to use in haversine function
                for(int i = 0; i < myList.size();++i){
                    places[i] = myList.get(i); }}

                this.distances = CalculateDistances(places, options);

        log.trace("buildResponse -> {}", this);
    }

    List<Integer> getDistances() {
        return distances;
    }
    List<Integer> CalculateDistances(Map[]places, Map options){
        distances = new ArrayList<>();
        for(int origin = 0; origin < this.places.length; origin++){
            int destination = (origin + 1 == this.places.length) ? 0 : (origin + 1);
            int dist = (int)Math.round(GreatCircleDistance.haversineFormula(
                    Double.parseDouble(places[origin].get("latitude").toString()),
                    Double.parseDouble(places[origin].get("longitude").toString()),
                    Double.parseDouble(places[destination].get("latitude").toString()),
                    Double.parseDouble(places[destination].get("longitude").toString()),
                    Double.parseDouble(options.get("earthRadius").toString())
            ));
            distances.add(dist);
        }
        return distances;
    }

}
