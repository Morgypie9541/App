package com.tripco.t01.TIP;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** This class defines the Config response that provides the client
 * with server specific configuration information.
 *  
 * When used with restful API services,
 * An object is created from the request JSON by the MicroServer using GSON.
 * The buildResponse method is called to set the configuration information.
 * The MicroServer constructs the response JSON from the object using GSON.
 *  
 * When used for testing purposes,
 * An object is created using the constructor below.
 * The buildResponse method is called to set the configuration information.
 * The getDistance method is called to obtain the distance value for comparisons.
 */
public class TIPConfig extends TIPHeader {
  private String serverName;
  private List<String> placeAttributes;
  private List<String> optimizations;
  private Map[] filters;

  private final transient Logger log = LoggerFactory.getLogger(TIPConfig.class);


  public TIPConfig() {
    this.requestType = "config";
    this.requestVersion = 5;
    this.serverName = "T01 Team Doggos";
    this.placeAttributes = Arrays.asList("name", "latitude", "longitude", "id", "municipality","region", "country", "continent" ,"altitude");
    this.optimizations=Arrays.asList("none","short");
    this.filters=new Map[2];
    Map<String,Object> temp=new HashMap<>();
    temp.put("name","type");
    temp.put("values",Arrays.asList("airport","heliport","balloonport","closed"));
    this.filters[0]=temp;
    Map<String,Object> temp2=new HashMap<>();
    temp2.put("name","country");
    temp2.put("values",Arrays.asList());
    this.filters[1]=temp2;
  }

  @Override
  public String toString() {
    log.debug(String.format("Current Config Contents -> {}\n"),this);
    return String.format("Current Config Contents:\nServer Name: %s\nPlace Attributes: %s\n",this.getServerName(),this.getPlaceAttributes());
  }

  @Override
  public void buildResponse() {
    log.trace("buildResponse -> {}", this);
  }

  Integer getVersion(){return this.requestVersion;}

  String getType(){return this.requestType;}

  String getServerName() {
    return this.serverName;
  }

  List<String> getOptimizations(){return this.optimizations;}

  Map[] getFilters(){return this.filters;}

  List<String> getPlaceAttributes() {
    return this.placeAttributes;
  }

}
