package com.tripco.t01.misc;

import java.lang.Math;
import java.util.Map;

/** Determines the distance between geographic coordinates.
 */
public class GreatCircleDistance {


    public static double radiusOfEarth;
    public static double haversineFormula(double latitude1, double longitude1, double latitude2, double longitude2, double radius){
        latitude1 = Math.toRadians(latitude1);
        latitude2 = Math.toRadians(latitude2);
        longitude1 = Math.toRadians(longitude1);
        longitude2 = Math.toRadians(longitude2);
        double latitudeDifference = latitude2 - latitude1;
        double longitudeDifference = longitude2 - longitude1;
        double partOne = Math.sin(latitudeDifference / 2.0) * Math.sin(latitudeDifference / 2.0)
                + Math.cos(latitude1) * Math.cos(latitude2)
                * Math.sin(longitudeDifference / 2.0) * Math.sin(longitudeDifference / 2.0);
        double centralAngle = 2.0 * Math.asin(Math.sqrt(partOne));

        radiusOfEarth = radius;

        return radiusOfEarth * centralAngle;
    }

}
