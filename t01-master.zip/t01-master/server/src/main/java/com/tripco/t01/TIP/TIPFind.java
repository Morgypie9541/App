package com.tripco.t01.TIP;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;

public class TIPFind extends TIPHeader{
    private String match;
    private Map[] narrow;
    private Integer limit;
    private Integer found;
    private Map[] places;
    private Integer httpStat;

    private final transient Logger log = LoggerFactory.getLogger(TIPFind.class);

    //TODO: Figure out why this isn't being recognized(TIPFind).
    TIPFind(int requestVersion, String match, Integer limit,Map[] narrow){
        this();
        this.requestVersion=requestVersion;
        this.match=match;
        this.narrow=narrow;
        if(limit!=0 && limit<100)
            this.limit=limit;
        this.found= 0;
        this.places=null;
    }

    private TIPFind(){this.requestType="find";
    this.requestVersion=5;
    }

    @Override
    public void buildResponse(){
        if(this.match.contains(";") || this.match.equals("") || this.match==null) {
            this.httpStat=400;
            log.trace("buildResponse -> {}",this);
        }

        this.queryDB();
        log.trace("buildResponse -> {}",this);
    }

    private final static String myDriver = "com.mysql.jdbc.Driver";
    private final static String myUrl = "jdbc:mysql://faure.cs.colostate.edu/cs314";
    private final static String user="cs314-db";
    private final static String pass="eiK5liet1uej";

    // fill in SQL queries to count the number of records and to retrieve the data
    public String addTypeFilter(List tempFilt){
        String temp="";
        for(int i=0;i<tempFilt.size();++i){
            if(i==0){
                temp=temp.concat("AND (");
            }
            if(i==tempFilt.size()-1){
                temp=temp.concat(" world.type like '%"+tempFilt.get(i)+"') ");
            }
            else{
                temp=temp.concat(" world.type like '%"+tempFilt.get(i)+"' or");
            }
        }
        return temp;
    }
    public String addCountryFilter(List tempFilt){
        String temp="";
        for(int i=0;i<tempFilt.size();++i){
            if(i==0)
                temp=temp.concat("AND (");
            if(i==tempFilt.size()-1)
                temp=temp.concat(" country.name like '"+tempFilt.get(i)+"') ");
            else
                temp=temp.concat(" country.name like '"+tempFilt.get(i)+"' or");
        }
        return temp;
    }
    // Arguments contain the username and password for the database
    public void queryDB(){
        String match2= this.match.replaceAll("[\\W]", "_");
        String count="select count(world.name) as counts FROM continent " +
                "INNER JOIN country ON continent.id = country.continent " +
                "INNER JOIN region ON country.id = region.iso_country " +
                "INNER JOIN world ON region.id = world.iso_region where (world.name like '%"+match2+"%' or" +
                " region.name like '%"+match2+"%'or world.municipality like '%"+match2+"%') ";
        // or country.name like '%"+match2+"%'
        String search="select world.name, world.latitude, world.longitude, world.id," +
                " world.municipality, region.name as iso_region, country.name as iso_country, continent.name as continent, world.altitude" +
                " FROM continent " +
                "INNER JOIN country ON continent.id = country.continent " +
                "INNER JOIN region ON country.id = region.iso_country " +
                "INNER JOIN world ON region.id = world.iso_region " +
                "where (world.name like '%"+match2+"%' or " +
                "region.name like '%"+match2+"%' or world.municipality like '%"+match2+"%') ";
        
        if(this.narrow!=null && this.narrow.length!=0) {
            if(this.narrow.length==1){
                String namee=(String)this.narrow[0].get("name");
                List tempType= (List) this.narrow[0].get("values");
                String temp="";
                if(namee.equals("type"))
                    temp= addTypeFilter(tempType);
                else if(namee.equals("country"))
                    temp=addCountryFilter(tempType);
                search=search.concat(temp);
                count=count.concat(temp);
            }
            else if(this.narrow.length==2){
                String namee1=(String)this.narrow[0].get("name");
                String namee2=(String)this.narrow[1].get("name");
                List tempFilt1 = (List) this.narrow[0].get("values");
                List tempFilt2 = (List) this.narrow[1].get("values");
                String tempType = "";
                String tempCountry = "";
                if(namee1.equals("type") && namee2.equals("country")){
                    tempType = addTypeFilter(tempFilt1);
                    tempCountry = addCountryFilter(tempFilt2);
                }
                else if(namee1.equals("country") && namee2.equals("type")){
                    tempType = addTypeFilter(tempFilt2);
                    tempCountry = addCountryFilter(tempFilt1);
                }
                search = search.concat(tempType);
                search = search.concat(tempCountry);
                count=count.concat(tempType);
                count=count.concat(tempCountry);
            } }

        if(this.limit!=null && this.limit!=0 && this.limit<100){
            search=search.concat(" order by world.name limit "+this.limit+";");
        }
        else{
            search=search.concat(" order by world.name limit 100;");
        }
        count=count.concat(";");
//        System.out.println(count+'\n');
//        System.out.println(search+'\n');

        try  {
            Class.forName(myDriver);
            // connect to the database and query
            try (Connection conn = DriverManager.getConnection(myUrl, user, pass);
                 Statement stCount = conn.createStatement();
                 Statement stQuery = conn.createStatement();
                 ResultSet rsCount = stCount.executeQuery(count);
                 ResultSet rsQuery = stQuery.executeQuery(search)
            ) {
                printJSON(rsCount, rsQuery);
            }
        } catch (Exception e) {
            System.err.println("Exception: "+e.getMessage());
        }
    }
    //
    private void printJSON(ResultSet count, ResultSet query) throws SQLException {
        count.next();
//        System.out.println("Limit: "+this.limit);
        this.found= count.getInt(1);
        int results=0;
        int arrLimit=100;
        if(this.found<arrLimit)
            arrLimit=this.found;
        if(this.limit!=null){
            if(this.limit<arrLimit && this.limit!=0)
                arrLimit=this.limit;
            if(this.limit>100)
                this.limit=100;
        }

        Map[] tempArr=new Map[arrLimit];
        // iterate through query results and print out the airport data
        while (query.next()) {
            if(!(results==this.found)){
                Map<String,String> temp=new HashMap<String, String>();
                //System.out.printf("  \"%s\"", query.getString("name"));
                temp.put("name", query.getString("name"));
                temp.put("latitude",query.getString("latitude"));
                temp.put("longitude",query.getString("longitude"));
                temp.put("id",query.getString("id"));
                temp.put("municipality",query.getString("municipality"));
                temp.put("region",query.getString("iso_region"));
                temp.put("country",query.getString("iso_country"));
                temp.put("continent",query.getString("continent"));
                temp.put("altitude",query.getString("altitude"));
                tempArr[results]=temp;
                ++results;
            }
        }
        this.places= tempArr;
    }
}



