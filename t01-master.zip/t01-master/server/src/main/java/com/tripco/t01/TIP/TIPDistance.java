package com.tripco.t01.TIP;

import com.tripco.t01.misc.GreatCircleDistance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;


/** Defines the TIP distance object.
 *
 * For use with restful API services,
 * An object is created from the request JSON by the MicroServer using GSON.
 * The buildResponse method is called to determine the distance.
 * The MicroServer constructs the response JSON from the object using GSON.
 *
 * For unit testing purposes,
 * An object is created using the constructor below with appropriate parameters.
 * The buildResponse method is called to determine the distance.
 * The getDistance method is called to obtain the distance value for comparisons.
 *
 */
public class TIPDistance extends TIPHeader {
  private Map origin;
  private Map destination;
  private Double earthRadius;
  private Integer distance;

  private final transient Logger log = LoggerFactory.getLogger(TIPDistance.class);


  TIPDistance(int requestVersion, Map origin, Map destination, Double earthRadius) {
    this();
    this.requestVersion = requestVersion;
    this.origin = origin;
    this.destination = destination;
    this.earthRadius = earthRadius;
    this.distance = 0;
  }


  private TIPDistance() {
    this.requestType = "distance";
    this.requestVersion=5;
  }


  @Override
  public void buildResponse() {
    this.distance = (int)Math.round(GreatCircleDistance.haversineFormula(
            Double.parseDouble(origin.get("latitude").toString()),
            Double.parseDouble(origin.get("longitude").toString()),
            Double.parseDouble(destination.get("latitude").toString()),
            Double.parseDouble(destination.get("longitude").toString()),
            Double.parseDouble(this.earthRadius.toString())
    ));
    log.trace("buildResponse -> {}", this);
  }

  @Override
  public String toString(){
    log.debug("Current Distance Contents -> {}\n",this);
    return String.format("Current Distance Contents:\nVersion: %d\nOrigin: "+this.origin.toString()+"\nDestination: "+this.destination.toString()+"\nRadius: %f\nDistance: %d\n",this.requestVersion,this.earthRadius,this.distance);
  }

  double getDistance() {
    return distance;
  }
}
